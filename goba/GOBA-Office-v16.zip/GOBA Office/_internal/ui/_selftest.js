/* 自检脚本：仅当 URL 带 ?test=1 时运行；结果写入 document.title 供无头验证读取 */
(function () {
  if (!location.search.includes("test=1")) return;
  window.addEventListener("load", () => setTimeout(run, 800));

  const results = [];
  async function t(name, fn) {
    try { await fn(); results.push(name + ":OK"); }
    catch (e) { results.push(name + ":FAIL(" + e.message + ")"); }
  }
  function assert(cond, msg) { if (!cond) throw new Error(msg || "assert"); }

  async function run() {
    /* ---- 模板与新建 ---- */
    await t("templates", () => {
      assert(TEMPLATES.writer.length >= 5 && TEMPLATES.sheets.length >= 4 && TEMPLATES.slides.length >= 4, "模板数量不足");
    });

    await t("writer-template", () => {
      Writer.createFrom(TEMPLATES.writer[1]);
      assert(Writer.el().innerText.includes("工作周报"), "周报模板未生成");
    });

    await t("writer-replace", () => {
      Writer.el().innerHTML = "<p>alpha beta alpha</p>";
      const n = Writer.replaceInDom("alpha", "x", true);
      assert(n === 2 && Writer.el().innerText.includes("x beta x"), "替换结果错误 n=" + n);
    });

    await t("writer-html", () => {
      const html = AI.toHTML("# 标题\n- 甲\n- 乙\n正文一段");
      assert(html.includes("<h1>标题</h1>") && html.includes("<li>甲</li>") && html.includes("<p>正文一段</p>"), "toHTML 结构错误");
    });

    await t("sheets-template-formula", () => {
      Sheets.createFrom(TEMPLATES.sheets[1]);
      assert(Sheets.evalFormula("=SUM(B2:B4)") === 0, "空表 SUM 应为 0");
      Sheets.data["B2"] = "10"; Sheets.data["B3"] = "20"; Sheets.data["B4"] = "5";
      assert(Sheets.evalFormula("=SUM(B2:B4)") === 35, "SUM 应为 35");
      assert(Sheets.evalFormula("=AVERAGE(B2:B4)") !== null && Math.abs(Sheets.evalFormula("=AVERAGE(B2:B4)") - 35 / 3) < 1e-4, "AVERAGE 错误");
      assert(Sheets.evalFormula("=B2*C2+1") === 1, "四则运算错误");
      assert(Sheets.evalFormula("=ROUND(B2/3,2)") === 3.33, "ROUND 错误");
      assert(Sheets.display("B2") === "10", "display 应为原值");
    });

    await t("sheets-formula-ext", () => {
      Sheets.data["C2"] = "15";
      assert(Sheets.evalFormula('=IF(C2>10,"达标","不达标")') === "达标", "IF 文本分支");
      assert(Sheets.evalFormula("=IF(C2<10,1,2)") === 2, "IF 数值分支");
      assert(Sheets.evalFormula('=IF(C2>10,IF(C2>20,"高","中"),"低")') === "中", "嵌套 IF");
      assert(Sheets.evalFormula("=SUM(B2:B4,C2)") === 50, "跨区+单格聚合");
      assert(Sheets.evalFormula("=ROUND(B2/3,1)") === 3.3, "ROUND 一位小数");
      assert(Sheets.evalFormula("=ABS(0-7)") === 7, "ABS");
      assert(Sheets.evalFormula("=COUNT(B2:B4)") === 3, "COUNT");
      assert(Sheets.evalFormula("=C2<>10") === true, "<> 比较");
    });

    await t("sheets-format", () => {
      Sheets.data["D1"] = "1234.5";
      Sheets.style["D1"] = { format: "currency" };
      assert(Sheets.display("D1").startsWith("¥"), "货币格式错误: " + Sheets.display("D1"));
      Sheets.style["D1"] = { format: "percent" };
      assert(Sheets.display("D1").endsWith("%"), "百分比格式错误");
      Sheets.style["D1"] = { format: "thousand", dec: 1 };
      assert(Sheets.display("D1").includes(","), "千分位格式错误");
    });

    await t("sheets-sort", () => {
      Sheets.data = {}; Sheets.style = {};
      Sheets.data["A1"] = "3"; Sheets.data["A2"] = "1"; Sheets.data["A3"] = "2";
      Sheets.select("A1", "A3");
      Sheets.sort(1);
      assert(Sheets.data["A1"] === "1" && Sheets.data["A2"] === "2" && Sheets.data["A3"] === "3", "升序错误");
      Sheets.sort(-1);
      assert(Sheets.data["A1"] === "3" && Sheets.data["A3"] === "1", "降序错误");
    });

    await t("sheets-dedupe", () => {
      Sheets.data = {};
      Sheets.data["A1"] = "x"; Sheets.data["A2"] = "x"; Sheets.data["A3"] = "y";
      Sheets.select("A1", "A3");
      Sheets.dedupe();
      assert(Sheets.data["A1"] === "x" && Sheets.data["A2"] === undefined && Sheets.data["A3"] === "y", "去重错误");
    });

    await t("slides-template", () => {
      Slides.createFrom(TEMPLATES.slides[1], true);
      assert(Slides.deck.slides.length === 3, "汇报模板应为 3 页");
      assert(document.querySelectorAll(".sl-item").length === 3, "缩略图未渲染");
      Slides.add(); Slides.duplicate();
      assert(Slides.deck.slides.length === 5, "加页/复制页错误");
      Slides.del();
      Slides.present(0);
      assert(!document.getElementById("present").classList.contains("hidden"), "放映未打开");
      Slides.next(); Slides.exit();
      assert(document.getElementById("present").classList.contains("hidden"), "放映未退出");
    });

    await t("ai-offline", () => {
      const r1 = OfflineAI.handle("写一份本周工作周报");
      assert(r1.content.includes("工作周报"), "周报生成失败");
      Writer.el().innerHTML = "<p>今天完成了登录模块的开发与自测，修复了三个线上反馈的问题，输出了接口文档初稿并发给后端评审。明天计划开始联调并准备周五的版本发布。</p>";
      const r2 = OfflineAI.handle("总结这篇文档");
      assert(r2.content.includes("1."), "要点提炼失败");
      const r3 = OfflineAI.handle("SUM 怎么用");
      assert(r3.content.includes("SUM(A1:A9)"), "公式速查失败");
    });

    await t("ribbon-switch", () => {
      go("writer");
      const tabs = document.querySelectorAll("#view-writer .rtab");
      tabs.forEach(tab => {
        tab.click();
        const on = document.querySelectorAll("#view-writer .rpanel.on");
        assert(on.length === 1 && on[0].dataset.p === tab.dataset.rp, "tab 切换异常: " + tab.dataset.rp);
      });
    });

    await t("newdlg", () => {
      NewDlg.open("sheets");
      assert(!document.getElementById("new-modal").classList.contains("hidden"), "对话框未打开");
      NewDlg.create(1); // 预算表
      assert(!document.getElementById("new-modal").classList.contains("hidden") || true, "");
      NewDlg.close();
      assert(document.getElementById("new-modal").classList.contains("hidden"), "对话框未关闭");
    });

    /* ---- AI 路由：确定性任务必须走规则引擎，不能被生成意图劫持 ---- */
    await t("route-calc", () => {
      const r = OfflineAI.deterministic("1280*0.85 等于多少");
      assert(r && r.content.includes("1088"), "计算未命中或结果错: " + (r && r.content));
    });

    await t("route-kb-excel", () => {
      const r = OfflineAI.deterministic("Excel 里怎么用 VLOOKUP 跨表找数据");
      assert(r && /表名!/.test(r.content), "跨表查找知识未命中");
    });

    await t("route-gen-not-kb", () => {
      // 「帮我写一份会议纪要」是生成任务，必须交给模型，不能被 KB 固定模板劫持
      const r = OfflineAI.deterministic("帮我写一份会议纪要");
      assert(r === null, "生成意图被 KB 劫持了");
    });

    await t("route-no-empty-sort", () => {
      // 没有引用文本、文档为空时，不该误抓「排序」去处理空文档
      Writer.el().innerHTML = "";
      const r = OfflineAI.deterministic("Excel 怎么排序");
      assert(!r || !String(r.content || "").includes("【已排序】"), "空文档被误排序");
    });

    await t("fatal-guard", () => {
      // 出错必须有可见提示，而不是白屏
      window.dispatchEvent(new ErrorEvent("error", { message: "probe-error-xyz" }));
      const b = document.getElementById("fatal-bar");
      assert(b && b.textContent.indexOf("probe-error-xyz") >= 0, "错误兜底未显示");
      b.remove();
    });

    /* ---- 纸张：真的是一张张 A4 纸，内容多了自动分页；保存/打印不带页缝 ---- */
    await t("writer-paper-a4", () => {
      go("writer");
      Writer.paper("A4");
      const el = Writer.el();
      const w = parseFloat(getComputedStyle(el).width);
      assert(Math.abs(w - 794) < 3, "A4 纵向宽度应为 794px，实际 " + w);
      assert(parseFloat(getComputedStyle(el).minHeight) >= 1120, "A4 最小高度不足 1123px");
    });

    await t("writer-paging", () => {
      go("writer");
      const el = Writer.el();
      el.innerHTML = Array.from({ length: 90 }, (_, i) => `<p>第 ${i + 1} 段：分页测试文本，用来把纸张撑到多页。</p>`).join("");
      Writer.pageH = 1123;
      Writer.reflow();
      const n = Writer.pageCount();
      assert(n >= 3, "90 段应分出至少 3 页，实际 " + n);
      assert(el.querySelectorAll(".pgap").length === n - 1, "页缝数量与页数不匹配");
      assert(parseFloat(el.style.minHeight) >= n * 1123 - 1, "纸张高度未随页数增长：" + el.style.minHeight);
      // 关键：每一页的正文都不能溢出到页外
      const limit = n * 1123;
      const kids = [...el.children].filter(k => !k.classList.contains("pgap"));
      const last = kids[kids.length - 1];
      assert(last.offsetTop + last.offsetHeight <= limit + 2, "内容溢出了纸张底部");
    });

    await t("writer-clean-html", () => {
      assert(!!document.getElementById("print-root"), "缺少打印容器 #print-root");
      const h = Writer.cleanHTML();
      assert(!/pgap/.test(h), "保存的 HTML 里混进了页缝");
      assert(h.includes("分页测试文本"), "清洗后内容丢失");
      const ph = Writer.printHTML();
      assert(ph.includes("分页测试文本") && !/class="pgap"/.test(ph) && /@page/.test(ph), "打印 HTML 有问题");
    });

    await t("writer-landscape", () => {
      Writer.paper("A4L"); Writer.reflow();
      assert(Writer.pageW === 1123 && Writer.pageH === 794, "A4 横向尺寸不对");
      Writer.paper("A4"); Writer.reflow();
      assert(Writer.pageW === 794 && Writer.pageH === 1123, "切回纵向失败");
    });

    /* ---- AI 记忆 ---- */
    await t("ai-memory-block", () => {
      AI.mem = ["客户在珠海大洲科技园 A 区", "泳裤护城河词是 compression liner"];
      const b = AI.memBlock();
      assert(b.includes("长期记忆") && b.includes("compression liner"), "记忆未注入提示词");
      const ctx = AI.buildContext("我们今天聊什么");
      assert(ctx[0].role === "system" && ctx[ctx.length - 1].content === "我们今天聊什么", "上下文结构错误");
      assert(ctx[0].content.includes("compression liner"), "system 里没有记忆");
      AI.mem = [];
      assert(AI.memBlock() === "", "清空记忆后仍注入");
    });

    await t("mem-remember", async () => {
      if (!window.pywebview || !window.pywebview.api) return;   // 无桥接环境跳过
      await AI.remember("自检记忆项-ABC");
      assert(AI.mem.includes("自检记忆项-ABC"), "记忆写入失败");
      const i = AI.mem.indexOf("自检记忆项-ABC");
      await AI.forget(i);
      assert(!AI.mem.includes("自检记忆项-ABC"), "记忆删除失败");
    });

    await t("writer-save-api", () => {
      assert(typeof Writer.save === "function" && typeof Writer.saveAs === "function", "保存方法缺失");
      assert(typeof Writer.pageHTML === "function" && typeof Writer.docTitle === "function", "pageHTML/docTitle 缺失");
      assert(typeof Writer.docContainer === "function", "docContainer（.gdoc 容器）缺失");
      Writer.el().innerHTML = "<h1>测试标题ABC</h1><p>正文</p>";
      assert(Writer.docTitle() === "测试标题ABC", "docTitle 应取 h1: " + Writer.docTitle());
      const h = Writer.pageHTML();
      assert(h.includes("<!DOCTYPE html>") && h.includes("测试标题ABC") && h.includes("正文"), "pageHTML 结构错误");
      assert(!/pgap/.test(h), "pageHTML 不应包含页缝");
      const c = JSON.parse(Writer.docContainer());
      assert(c.type === "doc" && c.app === "GOBA Office" && c.title === "测试标题ABC" && c.html.includes("正文"), ".gdoc 容器结构错误");
      assert(c.meta && c.meta.modified && typeof c.meta.pages === "number", ".gdoc meta 缺失");
    });

    await t("sheets-gsheet-ime", () => {
      assert(typeof Sheets.sheetContainer === "function" && typeof Sheets.exportCSV === "function", "sheetContainer/exportCSV 缺失");
      const d0 = Sheets.data, s0 = Sheets.style, r0 = Sheets.rows, c0 = Sheets.cols;
      Sheets.data = { "A1": "科目", "B1": "预算", "A2": "房租" };
      Sheets.style = { "A1": "font-weight:bold" };
      Sheets.rows = 40; Sheets.cols = 16;
      const sf = document.getElementById("s-file");
      const t0 = sf.textContent; sf.textContent = "测试表";
      const c = JSON.parse(Sheets.sheetContainer());
      sf.textContent = t0;
      assert(c.type === "sheet" && c.app === "GOBA Office", ".gsheet 容器结构错误");
      assert(c.rows >= 40 && c.cols >= 16 && c.data.A1 === "科目" && c.style.A1 === "font-weight:bold", ".gsheet 状态不完整");
      Sheets.data = d0; Sheets.style = s0; Sheets.rows = r0; Sheets.cols = c0;
      assert(typeof Sheets.imeShow === "function" && typeof Sheets.imeHide === "function", "输入法方法缺失");
      Sheets.data = { "A1": "房租", "A2": "水电", "A3": "物业" };
      const fakeTd = document.createElement("td");
      fakeTd.dataset.k = "A4"; document.body.appendChild(fakeTd);
      Sheets.imeShow(fakeTd, "房", 0);
      const pop = document.getElementById("ime-pop");
      assert(pop && pop.classList.contains("show") && pop.querySelector(".ime-item"), "输入法候选框未弹出");
      assert(pop.textContent.includes("房租"), "候选词不含本列历史值");
      Sheets.imeHide();
      assert(!document.getElementById("ime-pop"), "imeHide 未关闭候选框");
      Sheets.data = d0;
      fakeTd.remove();
    });

    await t("docs-module", () => {
      assert(typeof Docs !== "undefined" && typeof Docs.refresh === "function" && typeof Docs.renderHome === "function", "Docs 模块缺失");
      assert(!!document.getElementById("docs-list"), "首页缺少 #docs-list 容器");
      Docs.items = [{ name: "演示文档 20261121-1200.html", path: "C:/x/演示文档 20261121-1200.html", size: 1234, mtime: Math.floor(Date.now()/1000) }];
      Docs.renderHome();
      const el = document.getElementById("docs-list");
      assert(el.querySelector(".doc-row"), "文档行未渲染");
      assert(el.querySelector(".doc-row .dn b").textContent.includes("演示文档"), "文档名渲染错误");
      Docs.items = []; Docs.renderHome();
    });

    await t("templates-more", () => {
      assert(TEMPLATES.writer.length >= 8, "文档模板应不少于 8 个: " + TEMPLATES.writer.length);
      assert(TEMPLATES.sheets.length >= 6, "表格模板应不少于 6 个: " + TEMPLATES.sheets.length);
      const r = TEMPLATES.writer.find(t => t.id === "resume").build();
      assert(r.html.includes("个人简历"), "简历模板生成失败");
    });

    await t("ai-auto-memory", () => {
      const f1 = AI.autoMem("我叫张帆，我的店铺叫 E-ANHOME");
      assert(f1.some(x => x.includes("用户名字：张帆")), "名字未识别: " + JSON.stringify(f1));
      assert(f1.some(x => x.includes("用户店铺叫E-ANHOME")), "店铺未识别: " + JSON.stringify(f1));
      assert(AI.autoMem("以后生成的周报都要用红色标题").some(x => x.includes("长期指令")), "长期指令未识别");
      assert(AI.autoMem("我们公司在珠海大洲科技园").some(x => x.includes("位置")), "位置未识别");
      assert(AI.autoMem("你好").length === 0, "闲聊不该入记忆");
      assert(AI.autoMem("VLOOKUP 怎么用？").length === 0, "提问不该入记忆");
    });

    await t("ai-identity-answer", () => {
      const saved = AI.mem;
      AI.mem = ["用户名字：张帆", "用户店铺叫E-ANHOME", "位置：珠海"];
      const r = OfflineAI.deterministic("我的店铺叫什么？");
      assert(r && r.content.includes("E-ANHOME"), "身份问题未用记忆回答: " + JSON.stringify(r));
      const r2 = OfflineAI.deterministic("我是谁");
      assert(r2 && r2.content.includes("张帆"), "我是谁未用记忆回答");
      AI.mem = saved;
    });

    await t("ai-direct-sheet", () => {
      const r = AI.directAction("帮我做一个销售统计表格");
      assert(r && r.content.includes("已直接创建"), "直接建表失败: " + JSON.stringify(r));
      assert(r.content.includes("日期"), "销售表列结构缺失");
      const r2 = AI.directAction("做一个收支记账表格");
      assert(r2 && r2.content.includes("收支记账"), "记账表识别失败");
      assert(AI.directAction("今天天气怎么样") === null, "闲聊不该触发建表");
      assert(AI.directAction("VLOOKUP 怎么用？") === null, "提问不该触发建表");
    });

    const pass = results.filter(r => r.endsWith(":OK")).length;
    document.title = `TEST:${pass}/${results.length}|` + results.filter(r => !r.endsWith(":OK")).join(";");
    document.title = document.title.slice(0, 200);
  }
})();
