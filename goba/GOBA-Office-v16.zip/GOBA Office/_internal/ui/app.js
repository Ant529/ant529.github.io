/* GOBA Office 2.0 — 核心逻辑 */
"use strict";
window.onerror = (m, s, l) => { document.title = "JSERR:" + m + "@" + l; };

/* ================= 基础 ================= */
const bridge = {
  ready: false, _q: [],
  init() {
    if (window.pywebview && window.pywebview.api) { this.ready = true; this._flush(); }
    else window.addEventListener("pywebviewready", () => { this.ready = true; this._flush(); });
  },
  _flush() { const q = this._q; this._q = []; q.forEach(f => f()); },
  call(method, ...args) {
    // 桥未就绪（DOMContentLoaded 早于 pywebviewready）：入队等待，就绪后补发。
    // 之前的实现直接 reject，导致 AI.init 的记忆/历史加载在启动早期静默失败、永不重试
    if (this.ready) return window.pywebview.api[method](...args);
    return new Promise((resolve, reject) => {
      const tid = setTimeout(() => reject(new Error("客户端连接超时")), 30000);
      this._q.push(() => {
        clearTimeout(tid);
        window.pywebview.api[method](...args).then(resolve, reject);
      });
    });
  }
};
bridge.init();

function toast(msg, ms = 2200) {
  const t = document.getElementById("toast");
  t.textContent = msg; t.classList.add("show");
  clearTimeout(t._tid); t._tid = setTimeout(() => t.classList.remove("show"), ms);
}
const esc = s => String(s ?? "").replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
const ext = p => { const i = p.lastIndexOf("."); return i < 0 ? "" : p.slice(i).toLowerCase(); };
const baseName = p => p.replace(/[\\/]+$/, "").split(/[\\/]/).pop();
function fmtSize(n) { if (!n) return "—"; const u = ["B","KB","MB","GB","TB"]; let i = 0; while (n >= 1024 && i < 4) { n /= 1024; i++; } return n.toFixed(n >= 100 || i === 0 ? 0 : 1) + " " + u[i]; }
function fmtTime(ts) { const d = new Date(ts * 1000), p = x => String(x).padStart(2, "0"); return `${d.getFullYear()}-${p(d.getMonth()+1)}-${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}`; }
const TEXT_EXTS = [".txt",".md",".markdown",".json",".py",".js",".html",".css",".csv",".log",".ini",".bat",".yaml",".yml",".xml",".ts",".java"];
const IMAGE_EXTS = [".png",".jpg",".jpeg",".gif",".bmp",".webp",".ico"];

function showModal(html) {
  let m = document.getElementById("dyn-modal");
  if (m) m.remove();
  m = document.createElement("div");
  m.className = "modal"; m.id = "dyn-modal";
  m.innerHTML = `<div class="modal-box glass" style="width:min(520px,90vw)"><div class="modal-h"><h3>信息</h3><button class="x" onclick="this.closest('.modal').remove()">✕</button></div><div class="modal-body" style="display:block;font-size:13px;line-height:1.9;user-select:text">${html}</div></div>`;
  m.onclick = e => { if (e.target === m) m.remove(); };
  document.body.appendChild(m);
}

/* ================= 路由 / Ribbon ================= */
const LAZY = { files: false, sheets: false, images: false };
function go(name) {
  document.querySelectorAll(".rail-btn").forEach(b => b.classList.toggle("active", b.dataset.view === name));
  document.querySelectorAll(".view").forEach(v => v.classList.toggle("active", v.id === "view-" + name));
  if (name === "home") Home.loadRecent();
  else if (name === "files" && !LAZY.files) { LAZY.files = true; FM.boot(); }
  else if (name === "sheets" && !LAZY.sheets) { LAZY.sheets = true; Sheets.ensure(); }
  else if (name === "settings") LocalModel.refresh();
  if (name === "slides" && !Slides.deck) Slides.newBlank();
}
document.addEventListener("click", e => {
  const tab = e.target.closest(".rtab");
  if (tab) {
    const ribbon = tab.closest(".ribbon");
    ribbon.querySelectorAll(".rtab").forEach(t => t.classList.toggle("on", t === tab));
    ribbon.querySelectorAll(".rpanel").forEach(p => p.classList.toggle("on", p.dataset.p === tab.dataset.rp));
  }
});

/* =========================================================
   新建向导 + 模版
   ========================================================= */
const TEMPLATES = {
  writer: [
    { id: "blank", icon: "📄", name: "空白文档", desc: "从一张白纸开始", build: () => ({ title: "未命名文档", html: "<h1>未命名文档</h1><p></p>" }) },
    { id: "weekly", icon: "🗓", name: "工作周报", desc: "本周完成 / 问题 / 下周计划", build: () => {
      const d = new Date().toLocaleDateString("zh-CN");
      return { title: `工作周报 ${d}`, html: `<h1>工作周报（${d}）</h1><h2>一、本周完成</h2><ul><li>1.</li><li>2.</li><li>3.</li></ul><h2>二、遇到的问题</h2><ul><li></li></ul><h2>三、下周计划</h2><ul><li>1.</li><li>2.</li></ul><blockquote>备注：</blockquote>` };
    }},
    { id: "meeting", icon: "👥", name: "会议纪要", desc: "议题 / 结论 / 行动项", build: () => ({ title: "会议纪要", html: `<h1>会议纪要</h1><p><b>时间：</b><br><b>参会人：</b><br><b>记录人：</b></p><h2>议题一：</h2><p>结论：</p><h2>行动项</h2><table><tr><td>事项</td><td>负责人</td><td>截止</td></tr><tr><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td></tr></table>` }) },
    { id: "plan", icon: "🎯", name: "项目计划", desc: "目标 / 里程碑 / 分工", build: () => ({ title: "项目计划", html: `<h1>项目计划书</h1><h2>一、项目背景与目标</h2><p></p><h2>二、里程碑</h2><table><tr><td>阶段</td><td>时间</td><td>交付物</td></tr><tr><td></td><td></td><td></td></tr></table><h2>三、分工</h2><ul><li></li></ul><h2>四、风险与应对</h2><p></p>` }) },
    { id: "prd", icon: "📐", name: "产品需求", desc: "背景 / 需求 / 验收标准", build: () => ({ title: "产品需求文档", html: `<h1>产品需求文档（PRD）</h1><h2>1. 背景</h2><p></p><h2>2. 用户故事</h2><p>作为…，我希望…，以便…</p><h2>3. 功能需求</h2><ul><li></li></ul><h2>4. 验收标准</h2><ul><li></li></ul>` }) },
    { id: "notice", icon: "📢", name: "通知公告", desc: "事由 / 要求 / 落款", build: () => {
      const d = new Date().toLocaleDateString("zh-CN");
      return { title: "通知", html: `<h1>关于……的通知</h1><p>各部门：</p><p>&nbsp;&nbsp;&nbsp;&nbsp;为了……，现将有关事项通知如下：</p><p>一、</p><p>二、</p><p>三、请各部门高度重视，认真落实。</p><p style="text-align:right">特此通知。</p><p style="text-align:right">GOBA game<br>${d}</p>` };
    }},
    { id: "resume", icon: "🧑‍💼", name: "个人简历", desc: "信息 / 经历 / 技能", build: () => ({ title: "个人简历", html: `<h1>个人简历</h1><table><tr><td><b>姓名</b></td><td></td><td><b>电话</b></td><td></td></tr><tr><td><b>邮箱</b></td><td></td><td><b>求职意向</b></td><td></td></tr></table><h2>教育经历</h2><p>20XX.09 – 20XX.06　XX大学　XX专业　本科</p><h2>工作经历</h2><p>20XX.XX – 20XX.XX　XX公司　XX岗位</p><ul><li>负责……，达成……</li></ul><h2>专业技能</h2><ul><li></li></ul><h2>自我评价</h2><p></p>` }) },
    { id: "spec", icon: "📘", name: "操作手册", desc: "步骤 / 截图位 / 注意", build: () => ({ title: "操作手册", html: `<h1>操作手册</h1><h2>一、适用范围</h2><p></p><h2>二、操作步骤</h2><table><tr><td>步骤</td><td>操作</td><td>说明 / 截图</td></tr><tr><td>1</td><td></td><td></td></tr><tr><td>2</td><td></td><td></td></tr></table><h2>三、常见问题</h2><p><b>Q：</b><br><b>A：</b></p><blockquote>注意：执行前请先备份。</blockquote>` }) },
  ],
  sheets: [
    { id: "blank", icon: "📊", name: "空白表格", desc: "通用电子表格", data: null },
    { id: "budget", icon: "💰", name: "预算表", desc: "科目 / 预算 / 实际 / 差额", rows: [["科目","预算","实际","差额"],["人力","","","=B2-C2"],["市场","","","=B3-C3"],["设备","","","=B4-C4"],["合计","=SUM(B2:B4)","=SUM(C2:C4)","=B5-C5"]] },
    { id: "todo", icon: "✅", name: "任务清单", desc: "任务 / 负责人 / 状态", rows: [["任务","负责人","截止","状态"],["","","","待办"],["","","","待办"]] },
    { id: "sales", icon: "📈", name: "销售看板", desc: "月份 / 销售额 / 同比", rows: [["月份","销售额","同比"],["1月","",""],["2月","",""],["3月","",""],["合计","=SUM(B2:B4)",""]] },
    { id: "ledger", icon: "🧾", name: "收支记账", desc: "日期 / 项目 / 收入 / 支出", rows: [["日期","项目","收入","支出"],["","","",""],["","","",""],["合计","","=SUM(C2:C3)","=SUM(D2:D3)"]] },
    { id: "attendance", icon: "🕒", name: "考勤表", desc: "姓名 / 日期 / 出勤", rows: [["姓名","1","2","3","4","5","状态"],["","","","","","",""],["","","","","","",""]] },
  ],
  slides: [
    { id: "blank", icon: "🖥️", name: "空白演示", desc: "自由发挥", deck: null },
    { id: "report", icon: "📋", name: "工作汇报", desc: "封面 / 进度 / 计划", deck: { title: "工作汇报", slides: [{ title: "工作汇报", body: "汇报人：\n日期：", layout: "title", notes: "" }, { title: "本周进展", body: "要点一\n要点二", layout: "title-content", notes: "" }, { title: "下一步计划", body: "", layout: "title-content", notes: "" }] } },
    { id: "launch", icon: "🚀", name: "产品发布", desc: "亮点 / 演示 / 路线", deck: { title: "产品发布", slides: [{ title: "产品名称", body: "一句话卖点", layout: "title", notes: "" }, { title: "核心亮点", body: "亮点一\n亮点二\n亮点三", layout: "title-content", notes: "" }, { title: "路线图", body: "", layout: "title-content", notes: "" }] } },
    { id: "train", icon: "🎓", name: "培训课件", desc: "目标 / 内容 / 小结", deck: { title: "培训课件", slides: [{ title: "课程名称", body: "讲师：", layout: "title", notes: "" }, { title: "学习目标", body: "", layout: "title-content", notes: "" }, { title: "课程内容", body: "", layout: "title-content", notes: "" }, { title: "小结", body: "", layout: "title-content", notes: "" }] } },
  ]
};

const NewDlg = {
  type: "writer",
  open(type) {
    this.type = type || "writer";
    document.getElementById("new-modal").classList.remove("hidden");
    document.querySelectorAll("#nm-tabs button").forEach(b => b.classList.toggle("on", b.dataset.t === this.type));
    this.render();
  },
  close() { document.getElementById("new-modal").classList.add("hidden"); },
  switchType(t) { this.type = t; this.open(t); },
  render() {
    const list = document.getElementById("nm-list");
    list.innerHTML = TEMPLATES[this.type].map((t, i) => `
      <button class="mtpl" onclick="NewDlg.create(${i})">
        <span class="ti">${t.icon}</span><b>${esc(t.name)}</b><small>${esc(t.desc)}</small>
      </button>`).join("");
    document.getElementById("nm-title").textContent = { writer: "新建文档", sheets: "新建表格", slides: "新建演示" }[this.type];
  },
  create(i) {
    const t = TEMPLATES[this.type][i];
    if (this.type === "writer") { Writer.createFrom(t); }
    else if (this.type === "sheets") { Sheets.createFrom(t); }
    else { Slides.createFrom(t); }
    this.close();
  }
};

/* =========================================================
   启动中心
   ========================================================= */
const Home = {
  async loadRecent(force) {
    const el = document.getElementById("recent-table");
    try {
      const list = await bridge.call("get_recent");
      if (!list || !list.length) { el.innerHTML = `<div class="empty">还没有打开过文件</div>`; return; }
      el.innerHTML = list.map(r => {
        const ex = ext(r.path);
        const kind = IMAGE_EXTS.includes(ex) ? "图片" : ex === ".csv" ? "表格" : TEXT_EXTS.includes(ex) ? "文档" : "文件";
        const ic = kind === "图片" ? "🖼️" : kind === "表格" ? "📊" : kind === "文档" ? "📝" : "📄";
        return `<div class="recent-row" data-p="${esc(r.path)}">
          <span class="ic">${ic}</span>
          <div style="min-width:0"><div class="nm">${esc(baseName(r.path))}</div><div class="pt">${esc(r.path)}</div></div>
          <span class="kind">${kind}</span>
          <span></span>
          <time>${new Date(r.time * 1000).toLocaleString("zh-CN",{month:"2-digit",day:"2-digit",hour:"2-digit",minute:"2-digit"})}</time>
        </div>`;
      }).join("");
      el.querySelectorAll(".recent-row").forEach(row => row.onclick = () => FM.openPath(row.dataset.p, false));
    } catch (e) { el.innerHTML = `<div class="empty">客户端未连接</div>`; }
    if (force) toast("已刷新");
    this.loadDrives();
    Docs.refresh();
  },
  async loadDrives() {
    try {
      const ds = await bridge.call("drives");
      document.getElementById("home-drives").innerHTML = ds.map(d => {
        const used = d.total ? (1 - d.free / d.total) : 0;
        return `<div class="drive-row" onclick="FM.openPath('${esc(d.path)}',true)">
          <span>💽</span><span>${esc(d.path)}</span>
          <div class="bar"><i style="width:${(used * 100).toFixed(0)}%"></i></div>
          <span class="pct">${(used * 100).toFixed(0)}%</span>
        </div>`;
      }).join("");
    } catch (e) { /* ignore */ }
  },
  renderTemplates() {
    const icons = { writer: "📄", sheets: "📊", slides: "🖥️" };
    const flat = [];
    ["writer","sheets","slides"].forEach(k => TEMPLATES[k].forEach((t, i) => { if (t.id !== "blank") flat.push({ k, i, t }); }));
    document.getElementById("tpl-grid").innerHTML = flat.slice(0, 8).map(f => `
      <button class="tpl" onclick="NewDlg.open('${f.k}');setTimeout(()=>NewDlg.create(${f.i}),50)">
        <span class="ti">${f.t.icon}</span><b>${esc(f.t.name)}</b><small>${esc(f.t.desc)}</small>
      </button>`).join("");
  }
};

/* =========================================================
   我的文档：保存的文件都在这里，点一下直接打开
   ========================================================= */
const Docs = {
  items: [],
  async refresh() {
    const r = await bridge.call("docs_list").catch(() => null);
    this.items = (r && r.items) || [];
    this.renderHome();
  },
  renderHome() {
    const el = document.getElementById("docs-list");
    if (!el) return;
    if (!this.items.length) {
      el.innerHTML = `<div class="empty">还没有保存的文档<br><small>写完按 <b>Ctrl+S</b>，文件自动存到这里</small></div>`;
      return;
    }
    el.innerHTML = this.items.slice(0, 10).map(d => `
      <div class="doc-row" data-p="${esc(d.path)}">
        <span class="di">📝</span>
        <div class="dn"><b>${esc(d.name.replace(/\.html?$/i, ""))}</b>
          <small>${fmtTime(d.mtime)} · ${fmtSize(d.size)}</small></div>
        <button class="dd" data-p="${esc(d.path)}" title="删除">🗑</button>
      </div>`).join("");
    el.querySelectorAll(".doc-row").forEach(row => {
      row.onclick = e => {
        if (e.target.closest(".dd")) return;
        go("writer"); Writer.openPath(row.dataset.p);
      };
    });
    el.querySelectorAll(".dd").forEach(btn => {
      btn.onclick = e => { e.stopPropagation(); Docs.del(btn.dataset.p); };
    });
  },
  async del(p) {
    const r = await bridge.call("doc_delete", p).catch(() => null);
    if (r && r.ok) { toast("已删除"); Docs.refresh(); }
    else toast((r && r.error) || "删除失败");
  }
};

/* =========================================================
   文件管理
   ========================================================= */
const FM = {
  path: null, parent: null, entries: [], allEntries: [], sel: null, history: [], showHidden: false,
  async boot() {
    this.renderPlaces(); this.renderDrives();
    try {
      const cfg = await bridge.call("get_config");
      const first = cfg.recent && cfg.recent[0] && cfg.recent[0].path;
      await this.go(first ? first.replace(/[\\/][^\\/]+$/, "") : null);
    } catch (e) { await this.go(null); }
  },
  async go(p, push = true) {
    if (push && this.path && p !== this.path) this.history.push(this.path);
    if (!p) {
      const ds = await bridge.call("drives");
      this.path = null; this.parent = null; this.sel = null;
      document.getElementById("fm-path").value = "此电脑";
      const list = document.getElementById("fm-list");
      list.innerHTML = ds.map(d => `
        <div class="fm-item dir" data-path="${esc(d.path)}" data-dir="true">
          <div class="nm"><span class="ic">💽</span><span>${esc(d.path)} 本地磁盘</span></div>
          <span class="meta">磁盘</span><span class="meta">${fmtSize(d.free)} 可用</span><span class="meta">共 ${fmtSize(d.total)}</span>
        </div>`).join("");
      list.querySelectorAll(".fm-item").forEach(el => {
        el.onclick = () => this.select(el.dataset.path, el);
        el.ondblclick = () => this.go(el.dataset.path);
      });
      document.getElementById("fm-status").textContent = `${ds.length} 个磁盘`;
      this.updateActions(); this.markPlace("");
      return;
    }
    const r = await bridge.call("list_dir", p);
    if (!r.ok) return toast("打不开：" + r.error);
    this.path = r.path; this.parent = r.parent; this.allEntries = r.entries; this.sel = null;
    document.getElementById("fm-path").value = r.path;
    this.filter(document.getElementById("fm-filter").value);
    this.markPlace(r.path);
  },
  filter(kw) {
    kw = (kw || "").toLowerCase();
    this.entries = kw ? this.allEntries.filter(e => e.name.toLowerCase().includes(kw)) : this.allEntries;
    this.render();
  },
  back() { const p = this.history.pop(); if (p !== undefined) this.go(p, false); },
  up() { if (this.parent) this.go(this.parent); else this.go(null, false); },
  refresh() { this.go(this.path || null, false); },
  toggleHidden() { this.showHidden = !this.showHidden; toast(this.showHidden ? "显示隐藏文件（仅名称以 . 开头的）" : "已隐藏"); this.filter(document.getElementById("fm-filter").value); },
  render() {
    const list = document.getElementById("fm-list");
    const ents = this.showHidden ? this.entries : this.entries.filter(e => !e.name.startsWith("."));
    if (!ents.length) list.innerHTML = `<div class="empty">${this.entries.length ? "无匹配结果" : "此文件夹为空"}</div>`;
    else list.innerHTML = ents.map(e => {
      const ex = ext(e.name);
      let ic = "📄";
      if (e.is_dir) ic = "📁";
      else if (IMAGE_EXTS.includes(ex)) ic = "🖼️";
      else if ([".csv",".xlsx",".xls",".et"].includes(ex)) ic = "📊";
      else if (TEXT_EXTS.includes(ex)) ic = "📝";
      else if (ex === ".pdf") ic = "📕";
      else if ([".zip",".rar",".7z"].includes(ex)) ic = "🗜️";
      else if ([".exe",".msi"].includes(ex)) ic = "⚙️";
      else if ([".mp4",".mkv",".avi",".mov"].includes(ex)) ic = "🎬";
      else if ([".mp3",".wav",".flac"].includes(ex)) ic = "🎵";
      const kind = e.is_dir ? "文件夹" : ({ ".csv": "CSV 表格", ".png": "PNG 图片", ".jpg": "JPEG 图片", ".pdf": "PDF 文档", ".txt": "文本", ".md": "Markdown", ".exe": "应用程序" }[ex] || (ex ? ex.slice(1).toUpperCase() + " 文件" : "文件"));
      return `<div class="fm-item ${e.is_dir ? "dir" : ""}" data-path="${esc(e.path)}" data-dir="${e.is_dir}">
        <div class="nm"><span class="ic">${ic}</span><span title="${esc(e.name)}">${esc(e.name)}</span></div>
        <span class="meta">${kind}</span>
        <span class="meta">${e.is_dir ? "" : fmtSize(e.size)}</span>
        <span class="meta">${fmtTime(e.mtime)}</span>
      </div>`;
    }).join("");
    list.querySelectorAll(".fm-item").forEach(el => {
      el.onclick = () => this.select(el.dataset.path, el);
      el.ondblclick = () => this.openPath(el.dataset.path, el.dataset.dir === "true");
    });
    document.getElementById("fm-status").textContent = `${ents.length} 项`;
    this.updateActions();
  },
  select(path, el) {
    this.sel = path;
    document.querySelectorAll(".fm-item.sel").forEach(x => x.classList.remove("sel"));
    el.classList.add("sel");
    this.updateActions();
  },
  updateActions() { document.getElementById("fm-actions").classList.toggle("show", !!this.sel); },
  async openPath(p, isDir) {
    if (isDir) return this.go(p);
    const ex = ext(p);
    bridge.call("add_recent", p, "file").catch(() => {});
    if (IMAGE_EXTS.includes(ex)) { go("images"); return Images.openPath(p); }
    if (ex === ".csv") { go("sheets"); return Sheets.openPath(p); }
    if (TEXT_EXTS.includes(ex)) { go("writer"); return Writer.openPath(p); }
    const r = await bridge.call("open_external", p);
    if (!r.ok) toast("无法打开：" + r.error);
  },
  openSelected() { if (!this.sel) return toast("先选中一个文件"); const e = this.entries.find(x => x.path === this.sel); this.openPath(this.sel, e ? e.is_dir : false); },
  openExternal() { if (this.sel) bridge.call("open_external", this.sel); },
  reveal() { bridge.call("reveal_in_explorer", this.sel || this.path || "C:\\"); },
  async newFolder() {
    if (!this.path) return toast("请先进入某个文件夹");
    const name = prompt("新文件夹名称：", "新建文件夹");
    if (!name) return;
    const r = await bridge.call("mkdir", this.path, name);
    r.ok ? this.refresh() : toast("创建失败：" + r.error);
  },
  async pickImport() {
    try {
      const src = await bridge.call("pick_open", "any");
      if (!src) return;
      if (!this.path) return toast("请先进入目标文件夹");
      const r = await bridge.call("copy_file", src, this.path);
      r.ok ? (toast("已导入 " + baseName(src)), this.refresh()) : toast(r.error);
    } catch (e) { toast(e.message); }
  },
  async renameSelected() {
    if (!this.sel) return toast("先选中文件");
    const name = prompt("重命名为：", baseName(this.sel));
    if (!name) return;
    const r = await bridge.call("rename", this.sel, name);
    if (r.ok) { this.sel = null; this.refresh(); } else toast("重命名失败：" + r.error);
  },
  async deleteSelected() {
    if (!this.sel) return toast("先选中文件");
    if (!confirm(`确定删除「${baseName(this.sel)}」吗？（移入回收站）`)) return;
    const r = await bridge.call("delete", this.sel);
    if (r.ok) { this.sel = null; this.refresh(); toast("已移入回收站"); } else toast("删除失败：" + r.error);
  },
  async renderPlaces() {
    try {
      const places = await bridge.call("quick_places");
      document.getElementById("fm-places").innerHTML = places.map(p =>
        `<div class="fm-place" data-p="${esc(p.path)}">${p.name === "此电脑" ? "🖥️" : "📁"} ${p.name}</div>`).join("");
      document.querySelectorAll("#fm-places .fm-place").forEach(el => el.onclick = () => el.dataset.p ? this.go(el.dataset.p) : this.go(null));
    } catch (e) { }
  },
  async renderDrives() {
    try {
      const ds = await bridge.call("drives");
      document.getElementById("fm-drives").innerHTML = ds.map(d =>
        `<div class="fm-place" data-p="${esc(d.path)}">💽 ${esc(d.path)}<span class="sz">${fmtSize(d.free)}</span></div>`).join("");
      document.querySelectorAll("#fm-drives .fm-place").forEach(el => el.onclick = () => this.go(el.dataset.p));
    } catch (e) { }
  },
  markPlace(p) {
    document.querySelectorAll(".fm-place").forEach(el =>
      el.classList.toggle("on", p && el.dataset.p && p.toLowerCase().startsWith(el.dataset.p.toLowerCase())));
  }
};

/* =========================================================
   文字文档
   ========================================================= */
const Writer = {
  path: null, saved: true, zoomV: 1, fontSizeStep: 0, readOnly: false,
  el() { return document.getElementById("w-editor"); },
  cmd(cmd, val) { document.execCommand(cmd, false, val ?? null); this.el().focus(); this.markDirty(); },
  block(v) { document.execCommand("formatBlock", false, v); this.el().focus(); this.markDirty(); },
  brush() { toast("选中一段带格式的文字后，再点其他位置即可应用（简化版格式刷）"); },
  clearFmt() { document.execCommand("removeFormat"); this.cmd("formatBlock", "p"); },
  font(f) { this.cmd("fontName", f); },
  size(s) {
    const sel = window.getSelection();
    if (!sel.rangeCount) return;
    document.execCommand("fontSize", false, "7");
    this.el().querySelectorAll("font[size='7']").forEach(f => {
      const span = document.createElement("span");
      span.style.fontSize = s + "px";
      span.innerHTML = f.innerHTML;
      f.replaceWith(span);
    });
    this.markDirty();
  },
  growSize(d) {
    this.fontSizeStep = Math.max(-2, Math.min(4, this.fontSizeStep + d));
    const sizes = [12, 14, 16, 18, 20, 24, 28];
    this.el().style.fontSize = (14.5 + this.fontSizeStep * 2) + "px";
    document.getElementById("w-stat").textContent = "字号 " + (14.5 + this.fontSizeStep * 2);
  },
  lineHeight(v) { this.el().style.lineHeight = v; this.scheduleReflow(); },
  margin(v) {
    const el = this.el();
    const parts = String(v).split(" ").map(x => parseInt(x) || 0);
    el.style.paddingTop = parts[0] + "px";
    el.style.paddingBottom = parts[0] + "px";
    el.style.setProperty("--pg-side", (parts[1] || 62) + "px");
    el.style.paddingLeft = (parts[1] || 62) + "px";
    el.style.paddingRight = (parts[1] || 62) + "px";
    this.scheduleReflow();
  },
  /* 纸张：A4 纵向 794×1123px、横向 1123×794px（96dpi 下的真实尺寸） */
  paper(kind) {
    const el = this.el();
    const L = kind === "A4L";
    this.pageW = L ? 1123 : 794;
    this.pageH = L ? 794 : 1123;
    el.style.width = "min(" + this.pageW + "px,100%)";
    el.style.minHeight = this.pageH + "px";
    toast(L ? "A4 横向" : "A4 纵向");
    this.scheduleReflow(0);
  },
  bg(c) { this.el().style.background = c; },
  zoom(v) {
    const pg = this.el();
    if (v === "fit") { pg.style.transform = ""; this.zoomV = 1; }
    else { this.zoomV = parseFloat(v); pg.style.transform = `scale(${this.zoomV})`; pg.style.transformOrigin = "top center"; }
    document.getElementById("w-zoom").textContent = Math.round(this.zoomV * 100) + "%";
  },
  insertTable() { this.insertHTML("<table><tr><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr><tr><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr><tr><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr></table><p></p>"); },
  async insertImage() {
    try {
      const p = await bridge.call("pick_open", "image");
      if (!p) return;
      const r = await bridge.call("read_image", p);
      if (r.ok) this.insertHTML(`<img src="${r.data}" style="max-width:100%">`);
      else toast(r.error);
    } catch (e) { toast(e.message); }
  },
  insertLink() {
    const url = prompt("链接地址：", "https://");
    if (url) this.cmd("createLink", url);
  },
  insertText(kind) {
    const d = new Date();
    if (kind === "日期") this.insertHTML(d.toLocaleDateString("zh-CN"));
    else this.insertHTML(d.toLocaleTimeString("zh-CN", { hour: "2-digit", minute: "2-digit" }));
  },
  insertHTML(html) { this.el().focus(); document.execCommand("insertHTML", false, html); this.markDirty(); this.scheduleReflow(120); },
  wordCount() {
    const t = this.el().innerText;
    const chars = t.replace(/\s/g, "").length;
    const words = (t.match(/[a-zA-Z]+/g) || []).length;
    const paras = t.split(/\n+/).filter(x => x.trim()).length;
    showModal(`<b>字数统计</b><br>字符数（不含空白）：${chars}<br>英文单词：${words}<br>段落数：${paras}<br>总行数：${t.split("\n").length}`);
  },
  toggleFind() {
    document.getElementById("findbar").classList.toggle("hidden");
    document.getElementById("find-in").focus();
  },
  replaceInDom(find, repl, all) {
    if (!find) return 0;
    let count = 0;
    const walker = document.createTreeWalker(this.el(), NodeFilter.SHOW_TEXT);
    const nodes = [];
    while (walker.nextNode()) nodes.push(walker.currentNode);
    for (const n of nodes) {
      if (!n.nodeValue.includes(find)) continue;
      if (!all) { n.nodeValue = n.nodeValue.replace(find, repl); count++; break; }
      count += n.nodeValue.split(find).length - 1;
      n.nodeValue = n.nodeValue.split(find).join(repl);
    }
    return count;
  },
  replaceOne() { const n = this.replaceInDom(document.getElementById("find-in").value, document.getElementById("find-out").value, false); toast(n ? "已替换 1 处" : "未找到"); this.markDirty(); },
  replaceAll() { const n = this.replaceInDom(document.getElementById("find-in").value, document.getElementById("find-out").value, true); toast(`已替换 ${n} 处`); this.markDirty(); this.stat(); },
  preview() {
    this.readOnly = !this.readOnly;
    this.el().contentEditable = this.readOnly ? "false" : "true";
    toast(this.readOnly ? "只读预览模式（再点一次恢复编辑）" : "已恢复编辑");
  },
  markDirty() { if (!this.saved) return; this.saved = false; document.getElementById("w-file").textContent = "未保存"; },
  /* ---------- 分页：内容超过一页，就在页边界前插入页缝，纸随内容越长越多页 ---------- */
  pageW: 794, pageH: 1123, pageN: 1,
  reflow() {
    const el = this.el();
    if (!el) return;
    el.querySelectorAll(".pgap").forEach(g => g.remove());
    const cs = getComputedStyle(el);
    const padTop = parseFloat(cs.paddingTop) || 76;
    const padBottom = parseFloat(cs.paddingBottom) || 76;
    const usable = Math.max(240, this.pageH - padTop - padBottom);
    const GAP = 26;
    const kids = [...el.children].filter(k => !k.classList.contains("pgap"));
    if (!kids.length) {
      this.pageN = 1;
      el.style.minHeight = this.pageH + "px";
      this.stat();
      return;
    }
    /* 1) 先量每块的垂直占位（此刻页缝已清空，测量结果不受分页影响） */
    const hs = kids.map(k => {
      const s = getComputedStyle(k);
      return k.offsetHeight + (parseFloat(s.marginTop) || 0) + (parseFloat(s.marginBottom) || 0);
    });
    /* 2) 按累计高度切页：一块放不下就整体推到下一页 */
    let used = 0, gaps = 0;
    const cuts = new Set();
    kids.forEach((k, i) => {
      const h = hs[i];
      if (i > 0 && used > 1 && used + h > usable + 1) { cuts.add(i); gaps++; used = 0; }
      used += h;
      if (used > usable) used = 0;    // 单块比一整页还高，占满后归零，别连着把后面的也推走
    });
    /* 3) 倒序插入，避免边插边改索引 */
    for (let i = kids.length - 1; i >= 0; i--) {
      if (!cuts.has(i)) continue;
      const g = document.createElement("div");
      g.className = "pgap";
      g.contentEditable = "false";
      el.insertBefore(g, kids[i]);
    }
    el.querySelectorAll(".pgap").forEach((g, i) => { g.textContent = "第 " + (i + 2) + " 页"; });
    const h = (gaps + 1) * this.pageH;
    if (Math.abs(parseFloat(el.style.minHeight) - h) > 0.5) el.style.minHeight = h + "px";
    this.pageN = gaps + 1;
    this.stat();
  },
  scheduleReflow(ms) {
    clearTimeout(this._rf);
    this._rf = setTimeout(() => this.reflow(), ms === undefined ? 450 : ms);
  },
  pageCount() { return this.pageN || 1; },
  /* 去掉页缝的纯净 HTML：保存 / 预览 / 打印都用它 */
  cleanHTML() {
    const box = document.createElement("div");
    box.innerHTML = this.el().innerHTML;
    box.querySelectorAll(".pgap").forEach(g => g.remove());
    return box.innerHTML;
  },
  stat() {
    const t = this.el().innerText.replace(/\s/g, "");
    document.getElementById("w-stat").textContent = `字数 ${t.length} · 共 ${this.pageCount()} 页`;
  },
  /* 打印 / 另存为 PDF：走系统打印对话框；不可用时退回浏览器打开 */
  printCSS() {
    return `@page{size:A4;margin:20mm 21mm}
      html,body{margin:0;padding:0;background:#fff}
      .pdoc{font-family:"Microsoft YaHei",system-ui,sans-serif;font-size:14.5px;line-height:1.9;color:#26262b}
      .pdoc h1{font-size:26px;margin:6px 0 14px;line-height:1.4}
      .pdoc h2{font-size:20px;margin:20px 0 10px}
      .pdoc h3{font-size:16px;margin:16px 0 8px}
      .pdoc blockquote{border-left:3px solid #e6392e;padding:4px 0 4px 14px;color:#7d7d86;margin:12px 0}
      .pdoc table{border-collapse:collapse;margin:10px 0;width:100%}
      .pdoc table td{border:1px solid #ccc;padding:6px 12px}
      .pdoc img{max-width:100%}
      .pdoc h1,.pdoc h2,.pdoc h3{page-break-after:avoid;break-after:avoid}
      .pdoc table,.pdoc img,.pdoc tr{page-break-inside:avoid;break-inside:avoid}
      .pgap{display:none}`;
  },
  /* 完整的可打印 HTML（也用于「退回浏览器打印」） */
  printHTML() {
    return `<!DOCTYPE html><html><head><meta charset="utf-8"><style>${this.printCSS()}</style></head><body><div class="pdoc">${this.cleanHTML()}</div></body></html>`;
  },
  print() {
    const root = document.getElementById("print-root");
    if (!root) return toast("打印容器缺失");
    root.innerHTML = `<style>${this.printCSS()}</style><div class="pdoc">${this.cleanHTML()}</div>`;
    document.body.classList.add("printing");
    const done = () => document.body.classList.remove("printing");
    window.addEventListener("afterprint", done, { once: true });
    setTimeout(async () => {
      try {
        if (typeof window.print === "function") { window.print(); setTimeout(done, 1500); return; }
        throw new Error("当前环境不支持直接打印");
      } catch (e) {
        done();
        const p = await bridge.call("write_text", (this.path || "打印文档").replace(/\.html?$/i, "") + "_print.html", this.printHTML()).catch(() => null);
        if (p && p.ok) { bridge.call("open_external", p.path || ""); toast("已在浏览器打开，可直接打印或另存 PDF"); }
        else toast("打印不可用：" + e.message);
      }
    }, 60);
  },
  newBlank() { this.path = null; this.el().innerHTML = "<h1>未命名文档</h1><p></p>"; this.saved = false; document.getElementById("w-file").textContent = "未保存"; go("writer"); this.scheduleReflow(0); },
  createFrom(t) {
    const c = t.build();
    this.path = null; this.el().innerHTML = c.html;
    document.getElementById("w-file").textContent = c.title + "（未保存）";
    this.saved = false; go("writer"); this.scheduleReflow(0);
    toast("已创建：" + t.name);
  },
  async open() { try { const p = await bridge.call("pick_open", "text"); if (p) this.openPath(p); } catch (e) { toast(e.message); } },
  async openPath(p) {
    const r = await bridge.call("read_text", p);
    if (!r.ok) return toast(r.error);
    const ex = ext(p); let html;
    if (ex === ".gdoc") {
      try {
        const d = JSON.parse(r.content);
        if (d.type !== "doc") throw new Error("不是文档容器");
        html = d.html || "";
        this._created = d.meta && d.meta.created;
      } catch (e) { return toast("打不开文档文件：" + e.message); }
    }
    else if (ex === ".html" || ex === ".htm") html = r.content;
    else if (ex === ".md" || ex === ".markdown") html = this.md2html(r.content);
    else html = "<p>" + esc(r.content).replace(/\n/g, "<br>") + "</p>";
    this.path = p; this.el().innerHTML = html; this.saved = true;
    document.getElementById("w-file").textContent = baseName(p);
    go("writer"); this.stat(); this.scheduleReflow(0);
    bridge.call("add_recent", p, "file").catch(() => {});
    toast("已打开：" + baseName(p));
  },
  md2html(md) {
    const out = []; let inList = false;
    const inline = s => esc(s).replace(/\*\*(.+?)\*\*/g, "<b>$1</b>").replace(/\*(.+?)\*/g, "<i>$1</i>").replace(/`(.+?)`/g, "<code>$1</code>");
    for (const ln of md.split(/\r?\n/)) {
      const li = /^\s*[-*]\s+(.*)/.exec(ln);
      if (li) { if (!inList) { out.push("<ul>"); inList = true; } out.push(`<li>${inline(li[1])}</li>`); continue; }
      if (inList) { out.push("</ul>"); inList = false; }
      const h = /^(#{1,4})\s+(.*)/.exec(ln);
      if (h) out.push(`<h${h[1].length}>${inline(h[2])}</h${h[1].length}>`);
      else if (ln.trim() === "") out.push("");
      else out.push(`<p>${inline(ln)}</p>`);
    }
    if (inList) out.push("</ul>");
    return out.join("\n");
  },
  /* 自有文件格式 .gdoc：JSON 容器，把内容、样式、元数据全部装进去（像 WPS 的 .docx） */
  docContainer() {
    return JSON.stringify({
      app: "GOBA Office", format: 1, type: "doc",
      title: this.docTitle(),
      html: this.cleanHTML(),
      meta: {
        created: this._created || (this._created = new Date().toISOString()),
        modified: new Date().toISOString(),
        words: this.stat ? (this.stat() || { chars: 0 }).chars : 0,
        pages: (document.querySelectorAll("#writer .pgap").length || 0) + 1,
      },
    });
  },
  /* 完整可保存的 HTML（不带页缝） */
  pageHTML() {
    const title = ((this.el().querySelector("h1") || {}).textContent || baseName(this.path || "") || "未命名文档").trim();
    return "<!DOCTYPE html><html><head><meta charset='utf-8'><title>" + esc(title) + "</title></head><body>" + this.cleanHTML() + "</body></html>";
  },
  docTitle() {
    const t = ((this.el().querySelector("h1") || {}).textContent || "").trim();
    return (t || "未命名文档").slice(0, 40);
  },
  /* 保存：第一次按 Ctrl+S 自动在「我的文档」里生成 .gdoc 文件，不用选路径 */
  async save() {
    try {
      const payload = this.docContainer();
      let r;
      if (!this.path || !/\.gdoc$/i.test(this.path)) {
        const d = new Date();
        const ts = d.getFullYear() + String(d.getMonth() + 1).padStart(2, "0") + String(d.getDate()).padStart(2, "0")
          + "-" + String(d.getHours()).padStart(2, "0") + String(d.getMinutes()).padStart(2, "0");
        r = await bridge.call("doc_save", this.docTitle() + " " + ts + ".gdoc", payload);
      } else {
        r = await bridge.call("write_text", this.path, payload);
        if (r && r.ok) r.path = this.path;
      }
      if (r && r.ok) {
        this.path = r.path; this.saved = true;
        const f = document.getElementById("w-file");
        if (f) f.textContent = baseName(r.path) + " · 已保存 " + new Date().toLocaleTimeString("zh-CN", { hour: "2-digit", minute: "2-digit" });
        toast("已保存 " + baseName(r.path));
        bridge.call("add_recent", r.path, "file").catch(() => {});
        Docs.refresh();
      } else toast("保存失败：" + ((r && r.error) || "未知错误"));
    } catch (e) { toast(e.message); }
  },
  /* 另存为：自己挑位置 */
  async saveAs() {
    try {
      const p = await bridge.call("pick_save", this.docTitle() + ".gdoc", ".gdoc");
      if (!p) return;
      this.path = /\.gdoc$/i.test(p) ? p : p + ".gdoc";
      this.saved = false;
      await this.save();
    } catch (e) { toast(e.message); }
  },
  init() {
    this.el().innerHTML = "<h1>欢迎使用 GOBA Office 文档</h1><p>这是你的一张白纸 —— 点左侧「开始」可从模板创建周报、纪要、计划书。</p><p>提示：<b>Ctrl+S</b> 随时保存；「审阅」页里可以用 AI 润色与校对。</p>";
    this.el().addEventListener("input", () => { this.markDirty(); this.scheduleReflow(); });
    window.addEventListener("resize", () => this.scheduleReflow(200));
    // 自动保存：已保存过的文档每 30 秒静默落盘一次，不怕断电丢稿
    setInterval(() => { if (!this.saved && this.path) this.save(); }, 30000);
    this.stat();
    this.scheduleReflow(0);
  }
};

/* =========================================================
   表格
   ========================================================= */
const Sheets = {
  rows: 30, cols: 12, data: {}, style: {}, sel: "A1", anchor: null, path: null, frozen: false, _inited: false,
  ensure() { if (this._inited) return; this._inited = true; this.render(); },
  colName(i) { let s = ""; i++; while (i > 0) { s = String.fromCharCode(65 + (i - 1) % 26) + s; i = Math.floor((i - 1) / 26); } return s; },
  key(r, c) { return this.colName(c) + (r + 1); },
  parseRef(ref) { const m = /^([A-Z]+)(\d+)$/.exec(String(ref).toUpperCase()); return m ? { c: m[1].split("").reduce((a, ch) => a * 26 + ch.charCodeAt(0) - 64, 0) - 1, r: +m[2] - 1 } : null; },

  render() {
    let h = "<table class='sheet'><thead><tr><th class='rowh'></th>";
    for (let c = 0; c < this.cols; c++) h += `<th>${this.colName(c)}</th>`;
    h += "</tr></thead><tbody>";
    for (let r = 0; r < this.rows; r++) {
      h += `<tr><th class='rowh'>${r + 1}</th>`;
      for (let c = 0; c < this.cols; c++) h += `<td data-k="${this.key(r, c)}"></td>`;
      h += "</tr>";
    }
    h += "</tbody></table>";
    const wrap = document.getElementById("s-grid-wrap");
    wrap.innerHTML = h;
    // 事件委托：整张表只挂 3 个监听，不再给 360 个单元格分别绑定
    if (!this._delegated) {
      this._delegated = true;
      wrap.addEventListener("mousedown", e => {
        const td = e.target.closest("td"); if (!td) return;
        e.preventDefault(); this.onCellDown(td, e);
      });
      wrap.addEventListener("mousemove", e => {
        if (!this.dragging) return;
        const td = e.target.closest("td"); if (td) this.onCellOver(td);
      });
      wrap.addEventListener("dblclick", e => {
        const td = e.target.closest("td"); if (td) this.edit(td);
      });
    }
    this.refreshCells();
    this.select(this.sel);
  },
  refreshCells() {
    const wrap = document.getElementById("s-grid-wrap");
    wrap.querySelectorAll("td").forEach(td => {
      const k = td.dataset.k;
      const raw = this.data[k];
      const st = this.style[k] || {};
      const v = this.display(k);
      td.textContent = v;
      td.className = (this.isNum(v) ? "num " : "") + (st.bold ? "bold " : "");
      td.style.cssText = [
        st.bold ? "font-weight:700" : "", st.italic ? "font-style:italic" : "",
        st.underline ? "text-decoration:underline" : "",
        st.color ? "color:" + st.color : "", st.background ? "background:" + st.background : "",
        st.align ? "text-align:" + st.align : "",
      ].filter(Boolean).join(";");
      td.classList.toggle("sel", k === this.sel);
    });
    this.updateStatus();
  },
  display(k) {
    const raw = this.data[k];
    if (raw === undefined || raw === "") return "";
    const st = this.style[k] || {};
    let v = String(raw);
    if (v.startsWith("=")) { const ev = this.evalFormula(v); v = ev === null ? "#ERR" : String(ev); }
    if (v === "#ERR") return v;
    const n = Number(v);
    if (!isNaN(n) && v !== "" && st.format) {
      if (st.format === "number") v = n.toFixed(st.dec ?? 2);
      else if (st.format === "thousand") v = n.toLocaleString("zh-CN", { minimumFractionDigits: st.dec ?? 2, maximumFractionDigits: st.dec ?? 2 });
      else if (st.format === "percent") v = (n * 100).toFixed(st.dec ?? 1) + "%";
      else if (st.format === "currency") v = "¥" + n.toLocaleString("zh-CN", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
      else if (st.format === "date") { const d = new Date(n * 86400000 + Date.UTC(1899, 11, 30)); v = d.toLocaleDateString("zh-CN"); }
    }
    return v;
  },
  isNum(v) { return v !== "" && v !== "#ERR" && !isNaN(Number(v)) && !String(v).startsWith("="); },
  val(k) {
    const raw = this.data[k];
    if (raw === undefined) return 0;
    let v = String(raw);
    if (v.startsWith("=")) { const ev = this.evalFormula(v); return ev === null ? 0 : ev; }
    const n = Number(v);
    return isNaN(n) ? 0 : n;
  },
  rangeVals(a, b) {
    const A = this.parseRef(a), B = this.parseRef(b);
    if (!A || !B) return [];
    const out = [];
    for (let r = Math.min(A.r, B.r); r <= Math.max(A.r, B.r); r++)
      for (let c = Math.min(A.c, B.c); c <= Math.max(A.c, B.c); c++) {
        const k = this.key(r, c);
        if (this.data[k] !== undefined && this.data[k] !== "") {
          const n = Number(this.display(k));
          if (!isNaN(n)) out.push(n);
        }
      }
    return out;
  },
  /* 把公式片段按顶层逗号拆参（忽略引号与括号内的逗号） */
  splitArgs(s) {
    const out = [];
    let buf = "", depth = 0, q = null;
    for (const ch of String(s)) {
      if (q) { buf += ch; if (ch === q) q = null; continue; }
      if (ch === '"' || ch === "'") { q = ch; buf += ch; continue; }
      if (ch === "(") depth++;
      if (ch === ")") depth--;
      if (ch === "," && depth === 0) { out.push(buf); buf = ""; continue; }
      buf += ch;
    }
    if (buf.trim() !== "" || out.length) out.push(buf);
    return out;
  },

  /* 求值一个"公式体"（不带开头的 =）：IF / ABS / SQRT / ROUND / 聚合 / 比较 / 文本 */
  evalExpr(expr, depth) {
    depth = depth || 0;
    if (depth > 16) return null;
    let s = String(expr).trim();
    if (s === "") return null;

    /* IF（最先处理，保证分支惰性求值、支持嵌套） */
    if (/^IF\s*\(/i.test(s) && s.endsWith(")")) {
      const args = this.splitArgs(s.slice(s.indexOf("(") + 1, -1));
      if (args.length === 3) {
        const cond = this.evalExpr(args[0], depth + 1);
        if (cond === null) return null;
        return cond ? this.evalExpr(args[1], depth + 1) : this.evalExpr(args[2], depth + 1);
      }
    }

    /* 聚合 / 单参函数：循环替换以支持嵌套（如 SUM(A1,MAX(B1:B2))） */
    for (let pass = 0; pass < 8; pass++) {
      const before = s;
      s = s.replace(/\b(SUM|AVERAGE|AVG|MAX|MIN|COUNT)\s*\(([^()]*)\)/gi, (_, fn, inner) => {
        const vs = [];
        for (const part of this.splitArgs(inner)) {
          const p = part.trim();
          if (/^[A-Za-z]{1,2}\d{1,4}:[A-Za-z]{1,2}\d{1,4}$/.test(p)) {
            const [a, b] = p.split(":");
            vs.push(...this.rangeVals(a, b));
          } else if (/^[A-Za-z]{1,2}\d{1,4}$/.test(p)) {
            vs.push(Number(this.val(p.toUpperCase())));
          } else {
            const v = this.evalExpr(p, depth + 1);
            const n = Number(v);
            if (v !== null && v !== "" && !isNaN(n)) vs.push(n);
          }
        }
        if (!vs.length) return "0";
        const sum = vs.reduce((x, y) => x + y, 0);
        return String({
          SUM: sum, AVERAGE: sum / vs.length, AVG: sum / vs.length,
          MAX: Math.max(...vs), MIN: Math.min(...vs), COUNT: vs.length,
        }[fn.toUpperCase()]);
      });

      s = s.replace(/\bABS\s*\(([^()]*)\)/gi, (_, x) => {
        const v = Number(this.evalExpr(x, depth + 1));
        return isNaN(v) ? "0" : String(Math.abs(v));
      });
      s = s.replace(/\bSQRT\s*\(([^()]*)\)/gi, (_, x) => {
        const v = Number(this.evalExpr(x, depth + 1));
        return isNaN(v) || v < 0 ? "0" : String(Math.sqrt(v));
      });
      s = s.replace(/\bROUND\s*\(([^()]*)\)/gi, (_, inner) => {
        const a = this.splitArgs(inner);
        const v = Number(this.evalExpr(a[0], depth + 1));
        const d = a.length > 1 ? Math.min(10, Math.max(0, Math.trunc(Number(this.evalExpr(a[1], depth + 1)) || 0))) : 0;
        return isNaN(v) ? "0" : String(Math.round(v * Math.pow(10, d)) / Math.pow(10, d));
      });
      s = s.replace(/\bMAX\s*\(([^()]*)\)/gi, (_, inner) => {
        const vs = this.splitArgs(inner).map(x => Number(this.evalExpr(x, depth + 1))).filter(n => !isNaN(n));
        return vs.length ? String(Math.max(...vs)) : "0";
      });
      s = s.replace(/\bMIN\s*\(([^()]*)\)/gi, (_, inner) => {
        const vs = this.splitArgs(inner).map(x => Number(this.evalExpr(x, depth + 1))).filter(n => !isNaN(n));
        return vs.length ? String(Math.min(...vs)) : "0";
      });
      if (s === before) break;
    }

    /* 单元格引用 → 数值或带引号的文本 */
    s = s.replace(/\b[A-Za-z]{1,2}\d{1,4}\b/g, ref => {
      const v = this.val(ref.toUpperCase());
      return typeof v === "number" ? String(v) : JSON.stringify(String(v));
    });

    /* Excel 风格 → JS（先用占位符保护 <= >= <>，再统一转换 = 为 ==，最后还原） */
    const CMP = { "\u0001": "<=", "\u0002": ">=", "\u0003": "!==" };
    s = s.replace(/<=|>=|<>/g, m => ({ "<=": "\u0001", ">=": "\u0002", "<>": "\u0003" }[m]));
    s = s.replace(/([<>!=])=/g, "$1==");
    s = s.replace(/[\u0001\u0002\u0003]/g, m => CMP[m]);
    s = s.replace(/\bTRUE\b/gi, "true").replace(/\bFALSE\b/gi, "false");
    if (s.includes("&")) return null; /* 不支持 & 连接，宁可报错也不静默算错 */

    /* 白名单校验：只允许数字/运算符/括号/引号/白名单函数 */
    const bare = s.replace(/"(?:[^"\\]|\\.)*"|'(?:[^'\\]|\\.)*'/g, '""')
                  .replace(/Math\.(abs|sqrt|max|min|round|pow)\b/g, "M")
                  .replace(/\b(true|false)\b/g, "T");
    if (/[A-Za-z]/.test(bare)) return null;

    const r = Function(`"use strict";return (${s})`)();
    if (typeof r === "number") return isFinite(r) ? Math.round(r * 1e6) / 1e6 : null;
    if (typeof r === "string") return r;
    if (typeof r === "boolean") return r;
    return null;
  },

  evalFormula(f) {
    try {
      const r = this.evalExpr(f.slice(1));
      if (r === null || r === undefined || r === "") return null;
      return typeof r === "number" ? Math.round(r * 1e6) / 1e6 : r;
    } catch (e) { return null; }
  },

  /* 选择（含拖选范围） */
  onCellDown(td, e) {
    e.preventDefault(); // 防止拖选时带出文字选择
    this.dragging = true;
    if (!e.shiftKey) this.anchor = td.dataset.k;
    this.select(e.shiftKey && this.anchor ? this.anchor : td.dataset.k, td.dataset.k);
  },
  onCellOver(td) {
    if (!this.dragging || !this.anchor) return;
    this.select(this.anchor, td.dataset.k);
  },
  select(k, endK) {
    this.sel = k;
    const wrap = document.getElementById("s-grid-wrap");
    wrap.querySelectorAll("td").forEach(td => {
      td.classList.remove("sel", "inrange");
      if (endK && this.inRange(k, endK, td.dataset.k)) td.classList.add("inrange");
    });
    const end = endK || k;
    wrap.querySelector(`td[data-k="${k}"]`)?.classList.add("sel");
    if (!endK) wrap.querySelector(`td[data-k="${k}"]`)?.classList.add("inrange");
    const p = this.parseRef(k), q = this.parseRef(end);
    document.getElementById("s-name").value = (p.c === q.c && p.r === q.r) ? k : `${k}:${end}`;
    document.getElementById("s-range").textContent = (p.c === q.c && p.r === q.r) ? k : `${k}:${end}`;
    const f = document.getElementById("s-formula");
    f.value = this.data[k] ?? "";
    this.updateStatus();
  },
  inRange(a, b, k) {
    const A = this.parseRef(a), B = this.parseRef(b), K = this.parseRef(k);
    return K.r >= Math.min(A.r, B.r) && K.r <= Math.max(A.r, B.r) && K.c >= Math.min(A.c, B.c) && K.c <= Math.max(A.c, B.c);
  },
  rangeSel() {
    const nv = document.getElementById("s-name").value;
    if (nv.includes(":")) return nv.split(":");
    return [nv, nv];
  },
  updateStatus() {
    const [a, b] = this.rangeSel();
    const vs = this.rangeVals(a, b);
    const sum = vs.reduce((x, y) => x + y, 0);
    document.getElementById("s-count").textContent = `计数 ${vs.length}`;
    document.getElementById("s-sum").textContent = `求和 ${vs.length ? Math.round(sum * 100) / 100 : 0}`;
    document.getElementById("s-avg").textContent = `平均值 ${vs.length ? (sum / vs.length).toFixed(2) : 0}`;
  },
  /* ---------- GOBA 输入法：单元格联想输入 ----------
     输入时按当前列的历史值做前缀匹配，弹出候选框；↑↓ 选择、Enter 上屏、Esc 关闭 */
  imeHide() {
    const p = document.getElementById("ime-pop");
    if (p) p.remove();
    const f = document.getElementById("s-formula");
    this._ime = null;
  },
  imeShow(el, val, col) {
    const q = String(val || "").trim();
    if (!q || q.startsWith("=")) return this.imeHide();
    const row = this.parseRef(el.dataset.k || this.sel)?.r;
    const seen = [];
    for (let r = 0; r < this.rows && seen.length < 6; r++) {
      if (r === row) continue;
      const v = this.data[this.key(r, col)];
      if (v && String(v).toLowerCase().startsWith(q.toLowerCase()) && String(v) !== q && !seen.includes(String(v))) seen.push(String(v));
    }
    if (!seen.length) return this.imeHide();
    let p = document.getElementById("ime-pop");
    if (!p) { p = document.createElement("div"); p.id = "ime-pop"; document.body.appendChild(p); }
    p.classList.add("show");
    p.innerHTML = seen.map((c, i) => `<div class="ime-item${i === 0 ? " on" : ""}" data-v="${esc(c)}">${esc(c)}</div>`).join("");
    p.querySelectorAll(".ime-item").forEach((d, i) => d.onmousedown = e => { e.preventDefault(); this.imeApply(el, seen[i], true); });
    const r = el.getBoundingClientRect();
    p.style.left = r.left + "px";
    p.style.top = Math.min(r.bottom + 2, innerHeight - 200) + "px";
    this._ime = { el, cands: seen, idx: 0 };
  },
  imeMove(d) {
    const st = this._ime;
    if (!st) return;
    st.idx = Math.max(0, Math.min(st.cands.length - 1, st.idx + d));
    document.querySelectorAll("#ime-pop .ime-item").forEach((x, i) => x.classList.toggle("on", i === st.idx));
  },
  imeApply(el, v, commitAll) {
    if (el.tagName === "INPUT") {
      el.value = v;
      this.commit(this.sel, v);
      this.refreshCells();
      this.imeHide();
      if (commitAll) { this.move(1, 0); }
      return;
    }
    el.innerText = v;
    const rng = document.createRange(); rng.selectNodeContents(el);
    const s = getSelection(); s.removeAllRanges(); s.addRange(rng);
    this.imeHide();
    if (commitAll) { el.onblur = null; this.commit(el.dataset.k, v); this.refreshCells(); this.move(1, 0); }
  },
  edit(td) {
    td.setAttribute("contenteditable", "true"); td.focus();
    const rng = document.createRange(); rng.selectNodeContents(td);
    const s = getSelection(); s.removeAllRanges(); s.addRange(rng);
    const done = () => {
      td.removeAttribute("contenteditable");
      this.commit(td.dataset.k, td.innerText.trim());
      this.refreshCells();
      this.imeHide();
      const f = document.getElementById("s-formula");
      f.value = this.data[td.dataset.k] ?? "";
    };
    td.onblur = done;
    td.oninput = () => this.imeShow(td, td.innerText, this.parseRef(td.dataset.k).c);
    td.onkeydown = e => {
      if (this._ime) {
        if (e.key === "ArrowDown") { e.preventDefault(); this.imeMove(1); return; }
        if (e.key === "ArrowUp") { e.preventDefault(); this.imeMove(-1); return; }
        if (e.key === "Enter") { e.preventDefault(); const v = this._ime.cands[this._ime.idx]; this.imeApply(td, v, true); return; }
        if (e.key === "Escape") { this.imeHide(); return; }
      }
      if (e.key === "Enter") { e.preventDefault(); done(); this.move(1, 0); }
      if (e.key === "Tab") { e.preventDefault(); done(); this.move(0, 1); }
      if (e.key === "Escape") { td.removeAttribute("contenteditable"); this.refreshCells(); this.imeHide(); }
    };
  },
  commit(k, v) {
    if (v === "" || v === undefined) { delete this.data[k]; }
    else this.data[k] = v;
  },
  move(dr, dc) {
    const p = this.parseRef(this.sel);
    const r = Math.max(0, Math.min(this.rows - 1, p.r + dr));
    const c = Math.max(0, Math.min(this.cols - 1, p.c + dc));
    this.select(this.key(r, c));
    document.querySelector(`td[data-k="${this.sel}"]`)?.scrollIntoView({ block: "nearest", inline: "nearest" });
  },
  gotoCell(ref) {
    if (ref.includes(":")) this.select(ref.split(":")[0], ref.split(":")[1]);
    else this.select(ref.toUpperCase());
  },

  /* 格式 */
  fmt(prop) {
    const [a, b] = this.rangeSel();
    this.eachCell(a, b, k => {
      const st = this.style[k] = this.style[k] || {};
      st[prop] = !st[prop];
    });
    this.refreshCells();
  },
  fmtColor(prop, color) {
    const [a, b] = this.rangeSel();
    this.eachCell(a, b, k => { const st = this.style[k] = this.style[k] || {}; st[prop === "color" ? "color" : "background"] = color; });
    this.refreshCells();
  },
  align(v) {
    const [a, b] = this.rangeSel();
    this.eachCell(a, b, k => { const st = this.style[k] = this.style[k] || {}; st.align = v; });
    this.refreshCells();
  },
  numberFormat(f) {
    const [a, b] = this.rangeSel();
    this.eachCell(a, b, k => { const st = this.style[k] = this.style[k] || {}; if (f === "general") delete st.format; else st.format = f; });
    this.refreshCells(); toast("格式已应用：" + f);
  },
  decimals(d) {
    const [a, b] = this.rangeSel();
    this.eachCell(a, b, k => { const st = this.style[k] = this.style[k] || {}; st.dec = Math.max(0, (st.dec ?? 2) + d); if (!st.format) st.format = "number"; });
    this.refreshCells();
  },
  eachCell(a, b, fn) { const A = this.parseRef(a), B = this.parseRef(b); for (let r = Math.min(A.r,B.r); r <= Math.max(A.r,B.r); r++) for (let c = Math.min(A.c,B.c); c <= Math.max(A.c,B.c); c++) fn(this.key(r, c)); },

  /* 结构 */
  insertRow() { this.shiftStruct("row", 1); },
  insertCol() { this.shiftStruct("col", 1); },
  deleteRow() { this.shiftStruct("row", -1); },
  deleteCol() { this.shiftStruct("col", -1); },
  shiftStruct(kind, dir) {
    const p = this.parseRef(this.sel);
    const nd = {};
    const ns = {};
    Object.keys(this.data).forEach(k => {
      const q = this.parseRef(k);
      if (dir < 0 && ((kind === "row" && q.r === p.r) || (kind === "col" && q.c === p.c))) return;
      let r = q.r, c = q.c;
      if (dir > 0) { if (kind === "row" && q.r >= p.r) r++; if (kind === "col" && q.c >= p.c) c++; }
      nd[this.key(r, c)] = this.data[k];
      if (this.style[k]) ns[this.key(r, c)] = this.style[k];
    });
    this.data = nd; this.style = ns;
    this.render(); toast(dir > 0 ? "已插入" : "已删除");
  },
  freeze() {
    this.frozen = !this.frozen;
    document.querySelector("#s-grid-wrap table")?.classList.toggle("frozen", this.frozen);
    toast(this.frozen ? "已冻结首行" : "取消冻结");
  },
  sort(dir) {
    const [a, b] = this.rangeSel();
    const A = this.parseRef(a), B = this.parseRef(b);
    if (A.r === B.r && A.c === B.c) return toast("请先拖选要排序的区域");
    const rows = [];
    for (let r = Math.min(A.r, B.r); r <= Math.max(A.r, B.r); r++) {
      const row = [];
      for (let c = Math.min(A.c, B.c); c <= Math.max(A.c, B.c); c++) row.push([this.data[this.key(r, c)], this.style[this.key(r, c)]]);
      rows.push(row);
    }
    rows.sort((x, y) => {
      const vx = x[0][0] ?? "", vy = y[0][0] ?? "";
      const nx = Number(vx), ny = Number(vy);
      const cmp = (!isNaN(nx) && !isNaN(ny) && vx !== "" && vy !== "") ? nx - ny : String(vx).localeCompare(String(vy), "zh-CN");
      return cmp * dir;
    });
    for (let i = 0; i < rows.length; i++)
      for (let c = 0; c < rows[i].length; c++) {
        const k = this.key(Math.min(A.r, B.r) + i, Math.min(A.c, B.c) + c);
        if (rows[i][c][0] !== undefined) this.data[k] = rows[i][c][0]; else delete this.data[k];
        if (rows[i][c][1]) this.style[k] = rows[i][c][1]; else delete this.style[k];
      }
    this.refreshCells(); toast("已排序");
  },
  dedupe() {
    const [a, b] = this.rangeSel();
    const A = this.parseRef(a), B = this.parseRef(b);
    const seen = new Set();
    for (let r = Math.min(A.r, B.r); r <= Math.max(A.r, B.r); r++) {
      const rowKey = [];
      for (let c = Math.min(A.c, B.c); c <= Math.max(A.c, B.c); c++) rowKey.push(this.data[this.key(r, c)] ?? "");
      const key = rowKey.join("\u0001");
      if (seen.has(key)) for (let c = Math.min(A.c, B.c); c <= Math.max(A.c, B.c); c++) delete this.data[this.key(r, c)];
      seen.add(key);
    }
    this.refreshCells(); toast("已去除重复行");
  },
  summary() {
    const [a, b] = this.rangeSel();
    const vs = this.rangeVals(a, b);
    if (!vs.length) return toast("选区里没有数字");
    const sum = vs.reduce((x, y) => x + y, 0);
    showModal(`<b>统计摘要（${a}:${b}）</b><br>计数：${vs.length}<br>求和：${sum}<br>平均：${(sum / vs.length).toFixed(4)}<br>最大：${Math.max(...vs)}<br>最小：${Math.min(...vs)}`);
  },
  quickFunction(fn) {
    const [a, b] = this.rangeSel();
    const A = this.parseRef(a), B = this.parseRef(b);
    let formula;
    if (A.r === B.r && A.c === B.c) {
      // 单格：对上方连续数字区域求值
      const col = A.c; let r0 = A.r;
      while (r0 > 0 && this.data[this.key(r0 - 1, col)] !== undefined) r0--;
      if (r0 === A.r) return toast("上方没有数据，请先拖选区域");
      formula = `=${fn}(${this.key(r0, col)}:${this.key(A.r - 1, col)})`;
    } else formula = `=${fn}(${a}:${b})`;
    this.commit(this.sel, formula);
    this.refreshCells();
    document.getElementById("s-formula").value = formula;
    toast("已插入 " + formula);
  },
  quickChart() {
    const [a, b] = this.rangeSel();
    const A = this.parseRef(a), B = this.parseRef(b);
    const labels = [], vals = [];
    const vertical = B.r > A.r;
    if (vertical) {
      for (let r = A.r; r <= B.r; r++) {
        const raw = this.data[this.key(r, A.c)];
        const n = Number(this.display(this.key(r, A.c)));
        if (raw !== undefined && !isNaN(n)) { labels.push(String(this.display(this.key(r, A.c - 1 >= 0 ? A.c - 1 : A.c)) || this.key(r, A.c))); vals.push(n); }
      }
    } else {
      for (let c = A.c; c <= B.c; c++) {
        const raw = this.data[this.key(A.r, c)];
        const n = Number(this.display(this.key(A.r, c)));
        if (raw !== undefined && !isNaN(n)) { labels.push(this.colName(c)); vals.push(n); }
      }
    }
    if (!vals.length) return toast("选区里没有数字，无法绘图");
    const max = Math.max(...vals.map(Math.abs)) || 1;
    const bars = vals.map((v, i) => `
      <div style="display:flex;align-items:center;gap:8px;margin:6px 0">
        <span style="width:64px;font-size:11px;color:#666;text-align:right;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(labels[i])}</span>
        <div style="flex:1;background:rgba(0,0,0,.06);border-radius:99px;height:18px;overflow:hidden">
          <div style="width:${(Math.abs(v) / max * 100).toFixed(1)}%;height:100%;background:linear-gradient(90deg,#ff5f52,#c22318)"></div>
        </div>
        <span style="width:70px;font-size:11px;font-weight:600">${v}</span>
      </div>`).join("");
    showModal(`<b>快速图表（选区 ${a}:${b}）</b><div style="margin-top:10px">${bars}</div>`);
  },
  help(text) { showModal(`<b>公式帮助</b><br>${esc(text)}`); },

  /* 文件 */
  newBlank() { this.data = {}; this.style = {}; this.path = null; go("sheets"); this.render(); toast("新表格已就绪"); },
  createFrom(t) {
    this.data = {}; this.style = {}; this.path = null;
    if (t.rows) t.rows.forEach((row, ri) => row.forEach((cell, ci) => { if (cell !== "") this.data[this.key(ri, ci)] = cell; }));
    go("sheets"); this.render();
    toast("已创建：" + t.name);
  },
  async open() { try { const p = await bridge.call("pick_open", "csv"); if (p) this.openPath(p); } catch (e) { toast(e.message); } },
  async openPath(p) {
    const r = await bridge.call("read_text", p);
    if (!r.ok) return toast(r.error);
    if (ext(p) === ".gsheet") {
      try {
        const d = JSON.parse(r.content);
        if (d.type !== "sheet") throw new Error("不是表格容器");
        this.data = d.data || {}; this.style = d.style || {};
        this.rows = Math.max(40, d.rows || 40); this.cols = Math.max(16, d.cols || 16);
        this.path = p;
        go("sheets"); this.render();
        document.getElementById("s-file").textContent = baseName(p);
        bridge.call("add_recent", p, "file").catch(() => {});
        toast("已打开：" + baseName(p));
        return;
      } catch (e) { return toast("打不开表格文件：" + e.message); }
    }
    const rows = this.parseCSV(r.content);
    this.data = {}; this.style = {}; this.path = p;
    rows.forEach((row, ri) => row.forEach((cell, ci) => { if (cell !== "") this.data[this.key(ri, ci)] = cell; }));
    this.rows = Math.max(40, rows.length + 6);
    this.cols = Math.max(16, Math.max(...rows.map(x => x.length), 1) + 3);
    go("sheets"); this.render();
    document.getElementById("s-file").textContent = baseName(p);
    bridge.call("add_recent", p, "file").catch(() => {});
    toast("已打开：" + baseName(p));
  },
  parseCSV(text) {
    const rows = []; let row = [], cur = "", inQ = false;
    for (let i = 0; i < text.length; i++) {
      const ch = text[i];
      if (inQ) { if (ch === '"') { if (text[i + 1] === '"') { cur += '"'; i++; } else inQ = false; } else cur += ch; }
      else if (ch === '"') inQ = true;
      else if (ch === ",") { row.push(cur); cur = ""; }
      else if (ch === "\n" || ch === "\r") { if (ch === "\r" && text[i + 1] === "\n") i++; row.push(cur); rows.push(row); row = []; cur = ""; }
      else cur += ch;
    }
    if (cur !== "" || row.length) { row.push(cur); rows.push(row); }
    return rows;
  },
  /* 自有文件格式 .gsheet：数据、样式、行列数、公式全部装进一个 JSON 容器 */
  sheetContainer() {
    let maxR = -1, maxC = -1;
    Object.keys(this.data).forEach(k => { const q = this.parseRef(k); if (q) { maxR = Math.max(maxR, q.r); maxC = Math.max(maxC, q.c); } });
    return JSON.stringify({
      app: "GOBA Office", format: 1, type: "sheet",
      name: (document.getElementById("s-file").textContent || "表格").replace(/\s*·.*$/, "").trim() || "表格",
      rows: Math.max(this.rows, maxR + 6), cols: Math.max(this.cols, maxC + 3),
      data: this.data, style: this.style,
      meta: { modified: new Date().toISOString(), cells: Object.keys(this.data).length },
    });
  },
  async save() {
    try {
      if (!Object.keys(this.data).length) return toast("表格是空的，先填点内容");
      const payload = this.sheetContainer();
      let p = this.path;
      if (!p || !/\.gsheet$/i.test(p)) {
        p = await bridge.call("pick_save", "未命名表格.gsheet", ".gsheet");
        if (!p) return;
        if (!/\.gsheet$/i.test(p)) p += ".gsheet";
      }
      const res = await bridge.call("write_text", p, payload);
      if (res.ok) {
        this.path = p;
        const f = document.getElementById("s-file");
        if (f) f.textContent = baseName(p) + " · 已保存 " + new Date().toLocaleTimeString("zh-CN", { hour: "2-digit", minute: "2-digit" });
        toast("已保存 " + baseName(p));
        bridge.call("add_recent", p, "file").catch(() => {});
      } else toast("保存失败：" + res.error);
    } catch (e) { toast(e.message); }
  },
  async exportCSV() {
    try {
      let p = await bridge.call("pick_save", "表格.csv", ".csv");
      if (!p) return;
      if (!/\.csv$/i.test(p)) p += ".csv";
      let maxR = -1, maxC = -1;
      Object.keys(this.data).forEach(k => { const q = this.parseRef(k); maxR = Math.max(maxR, q.r); maxC = Math.max(maxC, q.c); });
      if (maxR < 0) return toast("表格是空的");
      const lines = [];
      for (let r = 0; r <= maxR; r++) {
        const cells = [];
        for (let c = 0; c <= maxC; c++) {
          let v = this.data[this.key(r, c)] ?? "";
          if (String(v).startsWith("=")) { const ev = this.evalFormula(String(v)); v = ev === null ? "#ERR" : ev; }
          v = String(v);
          if (/[",\n]/.test(v)) v = `"${v.replace(/"/g, '""')}"`;
          cells.push(v);
        }
        lines.push(cells.join(","));
      }
      const res = await bridge.call("write_text", p, lines.join("\r\n"), "utf-8-sig");
      if (res.ok) toast("已导出 CSV：" + baseName(p));
      else toast("导出失败：" + res.error);
    } catch (e) { toast(e.message); }
  },
  init() {
    const fb = document.getElementById("s-formula");
    fb.addEventListener("keydown", e => {
      if (this._ime) {
        if (e.key === "ArrowDown") { e.preventDefault(); this.imeMove(1); return; }
        if (e.key === "ArrowUp") { e.preventDefault(); this.imeMove(-1); return; }
        if (e.key === "Enter") { e.preventDefault(); this.imeApply(fb, this._ime.cands[this._ime.idx], true); return; }
        if (e.key === "Escape") { this.imeHide(); return; }
      }
      if (e.key === "Enter") {
        e.preventDefault();
        this.commit(this.sel, e.target.value.trim());
        this.refreshCells(); this.imeHide(); this.move(1, 0);
      }
    });
    fb.addEventListener("input", e => {
      const q = this.parseRef(this.sel);
      if (q) this.imeShow(e.target, e.target.value, q.c);
    });
    window.addEventListener("mouseup", () => { this.dragging = false; });
    // 启动时不渲染表格：等第一次进入「表格」模块再生成 DOM（省 300+ 节点与首屏布局）
  }
};

/* =========================================================
   演示
   ========================================================= */
const Slides = {
  deck: null, cur: 0, pCur: 0, path: null, theme: "red",
  newBlank() { this.createFrom({ name: "空白演示", deck: { title: "未命名演示", slides: [{ title: "第一页", body: "第一行要点\n第二行要点", layout: "title-content", notes: "" }] } }, true); },
  createFrom(t, silent) {
    this.deck = JSON.parse(JSON.stringify(t.deck));
    this.cur = 0; this.path = null; this.theme = "red";
    go("slides"); this.render();
    if (!silent) toast("已创建：" + t.name);
  },
  add() { this.deck.slides.push({ title: "第 " + (this.deck.slides.length + 1) + " 页", body: "", layout: "title-content", notes: "" }); this.cur = this.deck.slides.length - 1; this.render(); this.markDirty(); },
  del() {
    if (this.deck.slides.length <= 1) return toast("至少保留一页");
    this.deck.slides.splice(this.cur, 1);
    this.cur = Math.max(0, this.cur - 1); this.render(); this.markDirty();
  },
  duplicate() { this.deck.slides.splice(this.cur + 1, 0, JSON.parse(JSON.stringify(this.deck.slides[this.cur]))); this.cur++; this.render(); this.markDirty(); },
  layout(v) { this.deck.slides[this.cur].layout = v; this.render(); this.markDirty(); },
  theme(t) { this.theme = t; document.getElementById("sl-canvas").dataset.theme = t; toast("主题已切换"); },
  fontSize(d) {
    const b = document.getElementById("sl-body");
    b.style.fontSize = Math.max(12, Math.min(28, (parseFloat(b.style.fontSize) || 15) + d)) + "px";
  },
  align(v) { document.getElementById("sl-body").style.textAlign = v; },
  render() {
    document.getElementById("sl-stat").textContent = `${this.deck.title} · ${this.deck.slides.length} 页`;
    document.getElementById("sl-list").innerHTML = this.deck.slides.map((s, i) => `
      <div class="sl-item ${i === this.cur ? "on" : ""}" data-i="${i}">
        <span class="no">${i + 1}</span>
        <div style="min-width:0"><div class="tt">${esc(s.title || "（无标题）")}</div>
        <div class="mini">${esc(s.body.split("\n").slice(0, 3).join("  ·  ") || "空白页")}</div></div>
      </div>`).join("");
    document.querySelectorAll(".sl-item").forEach(el => el.onclick = () => { this.sync(); this.cur = +el.dataset.i; this.render(); });
    const s = this.deck.slides[this.cur];
    document.getElementById("sl-title").value = s.title;
    document.getElementById("sl-body").value = s.body;
    document.getElementById("sl-notes").value = s.notes || "";
    document.getElementById("sl-canvas").dataset.layout = s.layout || "title-content";
  },
  sync() {
    const s = this.deck.slides[this.cur];
    s.title = document.getElementById("sl-title").value;
    s.body = document.getElementById("sl-body").value;
    s.notes = document.getElementById("sl-notes").value;
  },
  markDirty() { document.getElementById("sl-file").textContent = "未保存"; },
  async save() {
    if (!this.deck) return;
    try {
      this.sync();
      let p = await bridge.call("pick_save", (this.deck.title || "演示") + ".gobadeck.json", ".gobadeck.json");
      if (!p) return;
      if (!/\.json$/i.test(p)) p += ".gobadeck.json";
      const r = await bridge.call("write_text", p, JSON.stringify(this.deck, null, 2));
      if (r.ok) { this.path = p; document.getElementById("sl-file").textContent = baseName(p); toast("已保存：" + baseName(p)); bridge.call("add_recent", p, "file").catch(() => {}); }
      else toast(r.error);
    } catch (e) { toast(e.message); }
  },
  async open() { try { const p = await bridge.call("pick_open", "deck"); if (p) this.openPath(p); } catch (e) { toast(e.message); } },
  async openPath(p) {
    const r = await bridge.call("read_text", p);
    if (!r.ok) return toast(r.error);
    try {
      const d = JSON.parse(r.content);
      if (!d.slides || !d.slides.length) throw new Error("缺 slides");
      d.slides.forEach(s => { s.layout = s.layout || "title-content"; s.notes = s.notes || ""; });
      this.deck = d; this.cur = 0; this.path = p; go("slides"); this.render();
      document.getElementById("sl-file").textContent = baseName(p);
      bridge.call("add_recent", p, "file").catch(() => {});
      toast("已打开：" + baseName(p));
    } catch (e) { toast("打不开演示文件：" + e.message); }
  },
  present(fromCur) {
    if (!this.deck) return;
    this.sync();
    this.pCur = fromCur ? this.cur : 0;
    document.getElementById("present").classList.remove("hidden");
    this.renderPresent();
  },
  renderPresent() {
    const s = this.deck.slides[this.pCur];
    document.getElementById("present-inner").innerHTML =
      `<h2>${esc(s.title)}</h2>` + s.body.split(/\n/).filter(x => x.trim()).map(l => `<li>${esc(l)}</li>`).join("");
  },
  next() { this.pCur = (this.pCur + 1) % this.deck.slides.length; this.renderPresent(); },
  exit() { document.getElementById("present").classList.add("hidden"); },
  init() {
    ["sl-title", "sl-body", "sl-notes"].forEach(id =>
      document.getElementById(id).addEventListener("input", () => { if (this.deck) { this.sync(); this.markDirty(); } }));
  }
};

/* =========================================================
   图片
   ========================================================= */
const Images = {
  path: null, list: [], idx: -1, zoomV: 1, natW: 0,
  async pickAndOpen() { try { const p = await bridge.call("pick_open", "image"); if (p) this.openPath(p); } catch (e) { toast(e.message); } },
  async openPath(p) {
    const r = await bridge.call("image_data", p, 2560);
    if (!r.ok) return toast(r.error);
    this.path = p; this.zoomV = 1;
    const img = document.getElementById("img-view");
    img.src = r.data; img.classList.add("show");
    document.getElementById("img-empty").classList.add("hide");
    img.onload = () => { this.natW = img.naturalWidth; this.apply(); };
    const dir = p.replace(/[\\/][^\\/]+$/, "");
    const lr = await bridge.call("list_dir", dir);
    this.list = lr.ok ? lr.entries.filter(e => !e.is_dir && IMAGE_EXTS.includes(ext(e.name))).map(e => e.path) : [p];
    this.idx = this.list.indexOf(p);
    this.renderStrip();
    this.apply();
    document.getElementById("img-stat").textContent = `${baseName(p)}（${this.idx + 1}/${this.list.length}）`;
    bridge.call("add_recent", p, "file").catch(() => {});
  },
  renderStrip() {
    // 只渲染当前张前后各 15 张，且用后端生成的小图 —— 不再把原图 base64 全塞进 DOM
    const strip = document.getElementById("img-strip");
    strip.innerHTML = "";
    const start = Math.max(0, this.idx - 15), end = Math.min(this.list.length, this.idx + 16);
    for (let i = start; i < end; i++) {
      const p = this.list[i];
      const t = document.createElement("img");
      t.className = "thumb" + (i === this.idx ? " on" : "");
      t.loading = "lazy";
      bridge.call("thumb", p, 96).then(r => { if (r.ok) t.src = r.data; }).catch(() => {});
      t.onclick = () => this.openPath(p);
      strip.appendChild(t);
    }
  },
  nav(d) { if (!this.list.length) return; this.openPath(this.list[(this.idx + d + this.list.length) % this.list.length]); },
  apply() {
    const img = document.getElementById("img-view");
    const fit = Math.min(1, (img.parentElement.clientWidth - 40) / (this.natW || 1));
    img.style.transform = `scale(${this.zoomV}) rotate(${this.rot || 0}deg)`;
    document.getElementById("img-zoom").textContent = Math.round(this.zoomV * 100) + "%";
  },
  zoom(f) { this.zoomV = Math.min(8, Math.max(0.05, this.zoomV * f)); this.apply(); },
  fit() { this.zoomV = 1; this.rot = 0; this.apply(); },
  actual() { this.zoomV = 1; this.apply(); toast("1:1 原始大小（相对适应基准）"); },
  rotate() { this.rot = ((this.rot || 0) + 90) % 360; this.apply(); },
  reveal() { if (this.path) bridge.call("reveal_in_explorer", this.path); },
  insertToWriter() {
    const img = document.getElementById("img-view");
    if (!img.src || !img.classList.contains("show")) return toast("先打开一张图片");
    go("writer");
    Writer.insertHTML(`<img src="${img.src}" style="max-width:100%">`);
    toast("已插入到当前文档");
  },
  init() {
    const stage = document.getElementById("img-stage");
    stage.addEventListener("wheel", e => {
      if (!document.getElementById("view-images").classList.contains("active")) return;
      e.preventDefault(); this.zoom(e.deltaY < 0 ? 1.12 : 0.9);
    }, { passive: false });
    window.addEventListener("dragover", e => e.preventDefault());
    window.addEventListener("drop", e => {
      e.preventDefault();
      const f = e.dataTransfer.files[0];
      if (!f) return;
      if (f.path && IMAGE_EXTS.includes(ext(f.path))) this.openPath(f.path);
      else if (f.type.startsWith("image/")) {
        const rd = new FileReader();
        rd.onload = () => {
          this.path = null; this.list = []; this.idx = -1;
          const img = document.getElementById("img-view");
          img.src = rd.result; img.classList.add("show");
          document.getElementById("img-empty").classList.add("hide");
          document.getElementById("img-stat").textContent = f.name + "（拖入预览）";
        };
        rd.readAsDataURL(f);
      } else toast("请拖入图片文件");
    });
  }
};

/* =========================================================
   AI 助手（本地模型 / 可选云端 / 离线引擎 三级）
   ========================================================= */
const AI = {
  msgs: [], busy: false, panelMsgs: [], _cfg: null, _local: null, mem: [],
  async cfg() {
    if (this._cfg) return this._cfg;
    this._cfg = await bridge.call("get_config").catch(() => ({ api_base: "", api_key: "", model: "" }));
    return this._cfg;
  },
  /* ---------- 记忆 ---------- */
  async loadMemory() {
    const r = await bridge.call("mem_read").catch(() => null);
    this.mem = (r && r.facts) || [];
    this.renderMem();
  },
  async remember(text) {
    const t = String(text || "").trim();
    if (t.length < 2) return;
    const r = await bridge.call("mem_add", t).catch(() => null);
    if (r && r.ok) { this.mem = r.facts; this.renderMem(); }
  },
  /* ---------- 自动记忆：不用说「记住」，AI 自己沉淀 ----------
     规则层：从用户消息里识别"会长期有用"的事实（身份/归属/偏好/指令） */
  /* ---------- 直接动作：AI 直接调用应用模块做出真实的东西（不只是给文字建议） ---------- */
  directAction(t) {
    const wantsSheet = /(做|建|创建|生成|弄|来)\s*(个|一张|一份|一个)?[^。？\n]{0,8}?(表格|统计表|登记表|记录表)/.test(t)
      || /(记账表|考勤表|台账|收支表)/.test(t);
    if (!wantsSheet) return null;
    const cols = /记账|收支/.test(t) ? ["日期", "项目", "收入", "支出", "备注"]
      : /考勤/.test(t) ? ["姓名", "日期", "上班时间", "下班时间", "状态"]
      : /销售|统计/.test(t) ? ["日期", "产品", "数量", "单价", "金额"]
      : ["项目", "负责人", "开始", "截止", "进度", "备注"];
    const title = /记账|收支/.test(t) ? "收支记账" : /考勤/.test(t) ? "考勤表" : /销售/.test(t) ? "销售统计" : /统计/.test(t) ? "数据统计" : "工作表格";
    const rows = [cols];
    for (let r = 0; r < 9; r++) rows.push(cols.map(() => ""));
    try { Sheets.createFrom({ name: title, rows }); } catch (e) { return null; }
    return { role: "ai", actions: false, content: `【已直接创建】「${title}」表格（${cols.length} 列），已经帮你切到表格页，直接填数就行。\n\n列结构：${cols.join(" / ")}\n\n列名想改就在表格里直接改；要加求和/平均公式，跟我说一声。` };
  },
  autoMem(text) {
    const t = String(text || "").trim();
    if (t.length < 4 || t.length > 220) return [];
    const facts = [];
    const add = f => { if (f && !facts.includes(f)) facts.push(f); };
    // 长期指令："以后……都要/记得/一律……"
    let m = /^以后.{0,14}?(?:都|要|记得|一律|请)(.{4,70})/.exec(t);
    if (m && !/[?？]$/.test(t)) add("长期指令：以后" + m[1].replace(/[。！!]+$/, "").trim());
    // 身份
    m = /(我叫|我的名字是)\s*([一-龥A-Za-z·]{1,12})/.exec(t);
    if (m) add("用户名字：" + m[2]);
    // 店铺 / 公司 / 品牌
    m = /(?:我们的|我的|我们|我)(公司|店铺|店|团队|品牌)(?:叫|名字叫|名字是|是)\s*([一-龥A-Za-z0-9-]{1,24})/.exec(t);
    if (m) add("用户" + m[1] + "叫" + m[2]);
    // 位置
    m = /(?:我们的|我的|我们|我)(?:公司|店铺|团队|办公室)(?:在|位于)\s*([一-龥A-Za-z0-9]{2,20})/.exec(t);
    if (m) add("位置：" + m[1]);
    // 产品 / 项目
    m = /(?:我们的|我的|我们|我)(?:主力产品|新品|产品|项目)(?:是|叫)\s*([一-龥A-Za-z0-9\s]{2,24})/.exec(t);
    if (m) add("产品/项目：" + m[1].trim());
    // 偏好
    m = /(我(?:喜欢|习惯|偏好|默认))(.{4,50})/.exec(t);
    if (m && !/[?？]$/.test(t)) add("偏好：" + m[1] + m[2].replace(/[。！!]+$/, "").trim());
    return facts;
  },
  /* 模型层：本地模型回答完后，后台悄悄问一次"这段对话有什么值得长期记住的"，
     不阻塞回答；没装本地模型时只用规则层 */
  async autoMemByModel(text, answer) {
    try {
      const mode = await this.mode();
      if (mode !== "local") return;
      const r = await bridge.call("local_chat",
        [{ role: "system", content: "你是记忆提取器。从对话里提取值得长期记住的用户事实（身份/归属/产品/偏好/长期指令）。只输出事实条目，每行一条，最多 2 条；没有就只输出：无" },
         { role: "user", content: "用户说：" + text.slice(0, 300) + " 助手答：" + String(answer).slice(0, 400) }], 120)
        .catch(() => null);
      if (!r || !r.ok) return;
      const out = String(r.content || "").trim();
      if (!out || /^无/.test(out)) return;
      for (const line of out.split(/\n/).map(x => x.replace(/^[-•\d.\s]+/, "").trim()).filter(x => x.length >= 4 && x.length <= 120 && !/[?？]|什么|怎么|多少|吗$/.test(x)).slice(0, 2)) {
        if (!this.mem.includes(line)) await this.remember(line);
      }
    } catch (e) { /* 后台任务，静默失败 */ }
  },
  async forget(i) {
    const r = await bridge.call("mem_del", i).catch(() => null);
    if (r && r.ok) { this.mem = r.facts; this.renderMem(); }
  },
  async clearMemory() {
    const r = await bridge.call("mem_clear").catch(() => null);
    if (r && r.ok) { this.mem = []; this.renderMem(); }
  },
  memBlock() {
    if (!this.mem.length) return "";
    return "\n\n[长期记忆 · 用户明确让你记住的事，回答时可以参考]\n- " + this.mem.slice(-15).join("\n- ");
  },
  renderMem() {
    const el = document.getElementById("ai-mem");
    if (!el) return;
    if (!this.mem.length) {
      el.innerHTML = `<div class="ai-skill" style="opacity:.6"><b>记忆 · 空</b><span>我会在对话里自动记住重点；也可以对我说「记住：……</span></div>`;
      return;
    }
    el.innerHTML = `<div class="card-h" style="margin-top:10px"><h3 style="font-size:12px">记忆 · ${this.mem.length} 条</h3>` +
      `<button class="btn-ghost sm" onclick="AI.clearMemory()">清空</button></div>` +
      this.mem.slice().reverse().map((f, k) =>
        `<div class="ai-skill"><b>${esc(f.length > 34 ? f.slice(0, 34) + "…" : f)}</b>` +
        `<span onclick="AI.forget(${this.mem.length - 1 - k})" style="cursor:pointer;color:var(--red)">点此删除</span></div>`).join("");
  },
  /* 组装带记忆与上下文的请求 */
  buildContext(text) {
    const hist = this.msgs.filter(m => m.role === "user" || m.role === "ai").slice(-8)
      .map(m => ({ role: m.role === "ai" ? "assistant" : "user", content: String(m.content).slice(0, 300) }));
    return [{ role: "system", content: this.sysPrompt() + this.memBlock() }, ...hist,
            { role: "user", content: text }];
  },
  persistHist() {
    bridge.call("hist_save", this.msgs.slice(-60)).catch(() => {});
  },
  async localStatus(force) {
    if (this._local && !force) return this._local;
    this._local = await bridge.call("local_status").catch(() => ({ installed: false, running: false }));
    return this._local;
  },
  async mode() {
    const l = await this.localStatus();
    if (l && l.installed) return "local";
    const c = await this.cfg();
    return c.api_key ? "online" : "offline";
  },
  async refreshBadges() {
    const l = await this.localStatus(true);
    const m = await this.mode();
    const label = m === "local"
      ? (l && l.running ? "本地大模型" : "本地大模型 · 待启动")
      : ({ online: "云端模型", offline: "离线引擎" }[m] || "离线引擎");
    ["ai-mode-badge", "ai-mode-badge2"].forEach(id => { const el = document.getElementById(id); if (el) el.textContent = label; });
    const c = await this.cfg();
    document.getElementById("ai-model").textContent =
      m === "local" ? (l && l.running ? "本地推理 · 完全离线" : "本地推理 · 提问时自动加载") : m === "online" ? (c.model || "云端模型") : "本地规则引擎 · 无需联网";
  },
  sysPrompt() {
    return "你是 GOBA Office 内置的办公 AI 助手。行为准则：1) 结论先行，再给细节；2) 输出用简体中文；3) 善用结构化（标题/列表/表格）；4) 用户让你写文档内容时直接给出可直接粘贴的成品；5) 不说客套话。";
  },
  async sendText(text) { go("ai"); document.getElementById("ai-text").value = text; this.send(); },
  async quickFromHome(text) { this.sendText(text); },
  async askAboutDoc(cmd) {
    const doc = Writer.el().innerText.slice(0, 4000);
    go("writer");
    this.togglePanel(true);
    this.sendPanel(`${cmd}。以下是我的文档：\n\n${doc}`);
  },
  async send() {
    if (this.busy) return;
    const box = document.getElementById("ai-text");
    const text = box.value.trim();
    if (!text) return;
    box.value = "";
    this.msgs.push({ role: "user", content: text });
    this.renderMain();
    await this.respond(text, r => { this.msgs.push(r); this.renderMain(); }, document.getElementById("ai-msgs"));
  },
  async sendPanel() {
    if (this.busy) return;
    const box = document.getElementById("ai-panel-text");
    const text = box.value.trim();
    if (!text) return;
    box.value = "";
    this.panelMsgs.push({ role: "user", content: text });
    this.renderPanel();
    await this.respond(text, r => { this.panelMsgs.push(r); this.renderPanel(); }, document.getElementById("ai-panel-msgs"));
  },
  async respond(text, push, scrollBox) {
    this.busy = true;
    document.querySelectorAll("#ai-send,.ai-panel-input .btn-red").forEach(b => b.disabled = true);
    const typing = document.createElement("div");
    typing.className = "msg ai typing"; typing.textContent = "处理中";
    scrollBox.appendChild(typing); scrollBox.scrollTop = 1e9;
    let result;

    // ⓪ 记忆指令：记住 / 查看记忆 / 忘记 —— 规则处理，不劳烦模型
    const mRec = /^(?:请?帮我)?(?:记住|记一下|记录一下|别忘了)[：:，,\s]*(.{2,120})/.exec(text.trim());
    if (mRec) {
      await this.remember(mRec[1]);
      result = { role: "ai", content: `记住了：${mRec[1]}\n\n现在长期记忆里有 ${this.mem.length} 条。之后问我「你记得什么」可以查看；说「AI 忘了这条」加序号可删除。重启软件也不会丢。`, engine: "规则" };
      typing.remove(); push(result); this.busy = false;
      document.querySelectorAll("#ai-send,.ai-panel-input .btn-red").forEach(b => b.disabled = false);
      this.persistHist();
      return;
    }
    if (/^(你|您)?(还记得|记得)?(哪些|什么).*(记|事)|你记住了什么|你的记忆|看看记忆|列出记忆/.test(text.trim())) {
      result = { role: "ai", content: this.mem.length ? `【长期记忆 · ${this.mem.length} 条】\n` + this.mem.map((f, i) => `${i + 1}. ${f}`).join("\n") + "\n\n这些跨会话保留；想删某条就说「AI 忘了第 N 条」。" : "【长期记忆】还是空的。对我说「记住：……」即可长期保存，重启软件也不会丢。", engine: "规则" };
      typing.remove(); push(result); this.busy = false;
      document.querySelectorAll("#ai-send,.ai-panel-input .btn-red").forEach(b => b.disabled = false);
      this.persistHist();
      return;
    }
    const mForget = /^(?:AI\s*)?(?:忘了?|删除|忘掉)\s*第\s*(\d+)\s*条/.exec(text.trim());
    if (mForget && this.mem.length) {
      const idx = parseInt(mForget[1], 10) - 1;
      const gone = this.mem[idx] !== undefined ? this.mem[idx] : null;
      if (gone !== null) await this.forget(idx);
      result = { role: "ai", content: gone !== null ? `忘了：${gone}\n\n剩余 ${this.mem.length} 条。` : `第 ${idx + 1} 条不存在，现在共 ${this.mem.length} 条。`, engine: "规则" };
      typing.remove(); push(result); this.busy = false;
      document.querySelectorAll("#ai-send,.ai-panel-input .btn-red").forEach(b => b.disabled = false);
      this.persistHist();
      return;
    }

    // ① 确定性任务（算数 / 日期 / 文本处理 / 办公知识）永远走规则引擎：
    //    结果精确，且不会被小模型的幻觉污染
    const det = OfflineAI.deterministic(text);

    if (det) {
      await new Promise(res => setTimeout(res, 120));
      result = det;
      result.engine = "规则";
    } else {
      const act = this.directAction(text);
      if (act) {
        await new Promise(res => setTimeout(res, 150));
        result = act;
        result.engine = "规则";
      } else {
        const mode = await this.mode();
        const memTag = this.mem.length ? ` · 参考${this.mem.length}条记忆` : "";
        if (mode === "local") {
          typing.textContent = "本地模型推理中（首次加载约几秒）";
          const r = await bridge.call("local_chat", this.buildContext(text), 768)
            .catch(e => ({ ok: false, error: e.message }));
          result = r.ok
            ? { role: "ai", content: r.content, actions: true, engine: "本地", meta: `${r.seconds}s · ${r.tps} tok/s${memTag}` }
            : { role: "err", content: "本地模型调用失败：" + r.error + "\n\n已回退到离线规则引擎的回答：\n\n" + OfflineAI.handle(text).content };
        } else if (mode === "online") {
          const c = await this.cfg();
          const r = await bridge.call("ai_chat", this.buildContext(text), c.api_base, c.api_key, c.model).catch(e => ({ ok: false, error: e.message }));
          result = r.ok ? { role: "ai", content: r.content, actions: true, engine: "云端", meta: memTag } : { role: "err", content: "云端调用失败：" + r.error + "（可继续使用离线引擎）" };
        } else {
          // 没有本地模型也没配云端：离线规则引擎兜底
          await new Promise(res => setTimeout(res, 350));
          result = OfflineAI.handle(text);
          result.engine = "离线";
        }
      }
    }
    typing.remove();
    push(result);
    this.busy = false;
    document.querySelectorAll("#ai-send,.ai-panel-input .btn-red").forEach(b => b.disabled = false);
    if (scrollBox) scrollBox.scrollTop = 1e9;
    this.persistHist();
    // 自动记忆：规则层立即提取（顺序写入，避免并发 mem_add 读改写竞态丢条目）；
    // 本地模型在后台再做一次智能提取
    for (const f of this.autoMem(text)) {
      if (!this.mem.includes(f)) await this.remember(f);
    }
    if (result.role === "ai" && result.engine !== "规则") this.autoMemByModel(text, result.content);
  },
  msgHTML(m, i, store, renderFn) {
    if (m.role === "user") return `<div class="msg user">${esc(m.content)}</div>`;
    if (m.role === "err") return `<div class="msg err">${esc(m.content)}</div>`;
    const acts = m.actions ? `<div class="ai-acts">
      <button onclick="AI.insertMsg(${store},${i})">➕ 插入到文档</button>
      <button onclick="AI.copyMsg(${store},${i})">⧉ 复制</button>
      <button onclick="AI.appendDoc(${store},${i})">📄 追加到文末</button>
    </div>` : "";
    const engName = { "本地": "本地大模型", "规则": "规则引擎 · 精确", "云端": "云端模型", "离线": "离线引擎" }[m.engine];
    const tag = engName ? `<div class="msg-eng">${esc(engName + (m.meta ? " · " + m.meta : ""))}</div>` : "";
    return `<div class="msg ai">${esc(m.content)}${tag}${acts}</div>`;
  },
  getMsg(store, i) { return (store === 0 ? this.msgs : this.panelMsgs)[i]; },
  insertMsg(store, i) {
    const m = this.getMsg(store, i);
    go("writer"); Writer.el().focus();
    document.execCommand("insertHTML", false, this.toHTML(m.content));
    toast("已插入到光标处");
  },
  appendDoc(store, i) {
    const m = this.getMsg(store, i);
    go("writer");
    Writer.el().insertAdjacentHTML("beforeend", "<hr>" + this.toHTML(m.content));
    Writer.markDirty(); Writer.stat();
    toast("已追加到文档末尾");
  },
  toHTML(text) {
    const out = [];
    let inList = false;
    for (const raw of String(text).split(/\n/)) {
      const l = esc(raw);
      const h = /^(#{1,3})\s+(.*)/.exec(raw.trim());
      if (h) {
        if (inList) { out.push("</ul>"); inList = false; }
        out.push(`<h${h[1].length}>${esc(h[2])}</h${h[1].length}>`);
      } else if (/^\s*[-*]\s+/.test(raw)) {
        if (!inList) { out.push("<ul>"); inList = true; }
        out.push(`<li>${l.replace(/^\s*[-*]\s*/, "")}</li>`);
      } else if (raw.trim() === "") {
        if (inList) { out.push("</ul>"); inList = false; }
      } else {
        if (inList) { out.push("</ul>"); inList = false; }
        out.push(`<p>${l}</p>`);
      }
    }
    if (inList) out.push("</ul>");
    return out.join("");
  },
  copyMsg(store, i) { navigator.clipboard.writeText(this.getMsg(store, i).content).then(() => toast("已复制")); },
  renderMain() {
    const box = document.getElementById("ai-msgs");
    box.innerHTML = this.msgs.map((m, i) => this.msgHTML(m, i, 0)).join("") ||
      `<div class="msg ai">你好！我是 GOBA AI 助手。<br><br>当前处于<b>离线引擎</b>模式：周报模板、大纲、润色、统计这些都能本地完成。要更强的生成能力，去「设置」配置 API Key 即可联网。<br><br>试试左侧的技能卡片 👈</div>`;
    box.scrollTop = 1e9;
  },
  renderPanel() {
    const box = document.getElementById("ai-panel-msgs");
    box.innerHTML = this.panelMsgs.map((m, i) => this.msgHTML(m, i, 1)).join("") ||
      `<div class="msg ai">选中文字后让我润色，或直接说需求。结果可以一键插入文档。</div>`;
    box.scrollTop = 1e9;
  },
  togglePanel(open) {
    const p = document.getElementById("ai-panel");
    const show = open === true ? true : p.classList.contains("hidden");
    p.classList.toggle("hidden", !show);
    if (show) { this.renderPanel(); document.getElementById("ai-panel-text").focus(); }
  },
  clear() { this.msgs = []; this.renderMain(); bridge.call("hist_clear").catch(() => {}); },
  async init() {
    document.getElementById("ai-text").addEventListener("keydown", e => {
      if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); this.send(); }
    });
    this.renderMain(); this.renderPanel();
    // 长期记忆 + 上次会话历史：重启软件后 AI 仍记得
    try {
      await this.loadMemory();
      const h = await bridge.call("hist_read").catch(() => null);
      const old = (h && h.messages) || [];
      if (old.length && !this.msgs.length) {
        this.msgs = old.map(m => ({ role: m.role === "assistant" ? "ai" : (m.role || "ai"), content: String(m.content || "") }));
        this.renderMain();
        toast("已恢复上次对话 " + this.msgs.length + " 条");
      }
    } catch (e) { }
  }
};

/* ---------- 离线引擎（本地规则 + 知识库 + 文本/计算工具，零依赖零联网） ---------- */
const KB = [
  { k: /^(你好|hi|hello|在吗|你是谁)/i, a: "我是 GOBA Office 内置 AI 助手。当前是本地引擎模式，能算数、处理文本、答办公问题、写周报大纲。装了本地大模型后，就可以像聊天一样问任意问题（见「设置 → 本地模型」）。" },
  { k: /word|排版|公文|文档规范|字体.*字号/i, a: "排版规范：\n标题：一级 18–22pt 加粗，二级 14–16pt，正文 10.5–12pt。\n行距 1.5 倍，段前段后 6pt。\n中文正文首行缩进 2 字符；数字与英文用半角。\n一页别超过 3 种字号、2 种字体。\n层级用「一、（一）1. (1)」，不要跳级。" },
  { k: /excel|表格.*技巧|函数|vlookup|xlookup|index.*match|透视/i, a: "查找匹配：\n· 同表：=VLOOKUP($A2,$D:$F,3,0)\n· 跨表：=VLOOKUP($A2,明细表!$A:$F,3,0) —— 区域前加「表名!」即可跨工作表\n· 跨文件：='[台账.xlsx]明细'!$A:$F\n· 反向查找用：=INDEX(返回列,MATCH(查找值,查找列,0))\n· 新版：=XLOOKUP(查找值,查找列,返回列,\"未找到\")\n四个参数：找什么、在哪找（查找列必须在区域第 1 列）、返回第几列、0=精确匹配。\n常见错：#N/A 找不到（查空格/文本数字）、#REF! 列号超出区域。" },
  { k: /excel|表格.*技巧|函数|透视/i, a: "表格基本功：\n=SUM/AVERAGE/COUNT/MAX/MIN 区域统计\n=ROUND(A1,2) 保留小数\n=IF(条件,真值,假值) 逻辑判断\n=SUMIFS(求和列,条件列1,条件1,条件列2,条件2) 多条件求和\n=COUNTIF(区域,\">100\") 条件计数\n透视：行放维度、列放分类、值放度量。\n数据规范：一列一字段、不合并单元格、不留空行、数值不加单位。" },
  { k: /ppt|演示|汇报.*结构|演讲/i, a: "演示结构：\n1) 封面：一句话结论\n2) 目录：3–4 个板块\n3) 每页一个观点，配图或数据\n4) 收尾：结论 + 下一步动作 + 需要的支持\n单页文字 ≤ 6 行，每行 ≤ 20 字；数字用图表不用口号。" },
  { k: /邮件|email|商务.*信|回复客户/i, a: "【商务邮件结构】\n主题：动词 + 对象 + 时间（例：请确认 11 月排期 / 周四前回复）\n开头一句说明来意；中间 3 条以内要点（编号）；结尾明确下一步与截止时间。\n原则：一封邮件只谈一件事；不写「尽快」，给具体时间。" },
  { k: /会议|纪要.*怎么写|议程/, a: "【会议纪要模板】\n时间 / 地点 / 参会人 / 记录人\n议题一：讨论要点 → 结论\n议题二：…\n行动项：事项 | 负责人 | 截止时间\n未决问题：…（下次会议跟进）\n要点：只记结论和行动项，不复述发言。" },
  { k: /okr|kpi|目标.*拆解|绩效/, a: "目标拆解：\nO（目标）：一句有方向感的话，例「把泳裤自然流量占比从 5% 提到 20%」\nKR（关键结果）：可量化、有基线、有截止，3 条以内。\n拆解：KR → 月度动作 → 周任务 → 负责人。\n检查：每个 KR 是否有人负责、有数据源、有复盘节点。" },
  { k: /可视化|图表.*选|柱状|折线|饼图/, a: "【图表选择】\n比大小 → 柱状图；看趋势 → 折线图；看结构占比 → 饼图（≤5 类）或堆叠条；看相关 → 散点图；看分布 → 直方图。\n戒律：纵轴从 0 开始（折线可例外并标注）；一张图一个结论；去掉多余网格线。" },
  { k: /公式|sum|求平均|average|count/i, a: "常用公式：\n=SUM(A1:A9) 求和\n=AVERAGE(A1:A9) 平均值\n=MAX / =MIN 最大最小\n=COUNT(A1:A9) 计数（只数数字）\n=ROUND(A1,2) 保留 2 位\n=A1*B1+100 四则混合\n坑：区域混入文本会被忽略；空单元格按 0；公式必须用英文标点、以 = 开头。" },
];

const OfflineAI = {
  docText() { return Writer.el().innerText.trim(); },

  /* 身份/归属类问题（"我的店铺叫什么"）：有记忆时从记忆精确回答；没问到就返回 null 让模型结合记忆上下文答 */
  isIdentityQuestion(t) {
    return /(?:我的|我们的)(?:名字|店铺|公司|团队|品牌|产品|项目).{0,6}(?:叫什么|是什么|是谁)|我是谁/.test(t);
  },
  identityAnswer(t) {
    if (!this.isIdentityQuestion(t)) return null;
    const mem = (typeof AI !== "undefined" && Array.isArray(AI.mem)) ? AI.mem : [];
    const grab = rx => { const f = mem.find(x => rx.test(x)); const m = f ? rx.exec(f) : null; return m ? (m[1] || "").trim() : null; };
    const name = grab(/^用户名字：(.+)/);
    const org = grab(/^用户(?:店铺|公司|店|品牌|团队)叫(.+)/);
    const loc = grab(/^位置：(.+)/);
    const prods = mem.filter(x => /^产品\/项目：/.test(x)).map(x => x.replace(/^产品\/项目：/, ""));
    const ask = { name: /我是谁|名字/.test(t), org: /店铺|公司|团队|品牌/.test(t), prod: /产品|项目/.test(t), loc: /在哪|哪里|位置/.test(t) };
    const lines = [];
    if (ask.name && name) lines.push("你的名字是 " + name);
    if (ask.org && org) lines.push("你的店铺/公司叫 " + org);
    if (ask.loc && loc) lines.push("位置在 " + loc);
    if (ask.prod && prods.length) lines.push("在做产品/项目：" + prods.join("、"));
    if (!lines.length) return null;
    return { role: "ai", content: "我记得：\n" + lines.join("\n") + "\n\n—— 来自我的长期记忆；如有不对，说「记住：……」即可纠正。" };
  },

  calc(t) {
    if (!/(等于多少|计算|算一下|多少|[\d)]\s*[+\-*/×÷])/.test(t)) return null;
    const pct = /([\d.]+)\s*%\s*(?:of|的)\s*([\d.]+)/i.exec(t);
    if (pct) return `算出来了：${pct[1]}% × ${pct[2]} = ${(parseFloat(pct[1]) / 100 * parseFloat(pct[2])).toFixed(4).replace(/\.?0+$/, "")}`;
    let expr = t.replace(/[计算等于多少请问一下帮我算的结果是]/g, "")
      .replace(/[，,]/g, " ").replace(/×/g, "*").replace(/÷/g, "/")
      .replace(/%/g, "/100").replace(/[（]/g, "(").replace(/[）]/g, ")").trim();
    expr = expr.replace(/[^\d+\-*/().\s]/g, "");
    if (!/\d/.test(expr) || !/[+\-*/]/.test(expr)) return null;
    try {
      const v = Function(`"use strict";return (${expr})`)();
      if (typeof v !== "number" || !isFinite(v)) return null;
      return `算出来了：${expr.replace(/\s+/g, "")} = ${Math.round(v * 1e10) / 1e10}`;
    } catch (e) { return null; }
  },

  dates(t) {
    const ds = t.match(/\d{4}[-/.]\d{1,2}[-/.]\d{1,2}/g);
    if (!ds) return null;
    const p = s => new Date(s.replace(/[-/.]/g, "-") + "T00:00:00");
    if (ds.length >= 2) {
      const d1 = p(ds[0]), d2 = p(ds[1]);
      if (isNaN(d1) || isNaN(d2)) return null;
      const days = Math.round((d2 - d1) / 86400000);
      return `算好了：${ds[0]} → ${ds[1]}：相差 ${Math.abs(days)} 天（约 ${(Math.abs(days) / 7).toFixed(1)} 周 / ${(Math.abs(days) / 30.4).toFixed(1)} 个月）`;
    }
    const d = p(ds[0]);
    if (isNaN(d)) return null;
    const wk = ["日", "一", "二", "三", "四", "五", "六"][d.getDay()];
    let extra = "";
    const add = /(\d+)\s*(天|日|周|个月)\s*(后|以后|之后)/.exec(t);
    if (add) {
      const n = +add[1], unit = add[2], nd = new Date(d);
      if (unit === "周") nd.setDate(nd.getDate() + n * 7);
      else if (unit === "个月") nd.setMonth(nd.getMonth() + n);
      else nd.setDate(nd.getDate() + n);
      extra = `；${n}${unit}后是 ${nd.toLocaleDateString("zh-CN")}（星期${["日","一","二","三","四","五","六"][nd.getDay()]}）`;
    }
    return `${ds[0]} 是星期${wk}，当年第 ${Math.ceil((d - new Date(d.getFullYear(), 0, 1)) / 86400000) + 1} 天${extra}`;
  },

  textTool(t) {
    const src = (t.match(/[「“"]([\s\S]+)[」”"]/) || [])[1] || this.docText();
    if (/统计|多少字|字数/.test(t)) {
      if (!src) return null;
      const chars = src.replace(/\s/g, "").length;
      return { role: "ai", content: `这段文字：字符数（不含空白）${chars}；行数 ${src.split(/\n/).filter(x => x.trim()).length}；中文 ${(src.match(/[\u4e00-\u9fa5]/g) || []).length} 字；英文单词 ${(src.match(/[a-zA-Z]+/g) || []).length} 个` };
    }
    if (!src) return null;
    if (/去重/.test(t)) {
      const seen = new Set(), out = [];
      src.split(/\n/).forEach(l => { const k = l.trim(); if (k && !seen.has(k)) { seen.add(k); out.push(l); } });
      return { role: "ai", actions: true, content: "去好了：\n" + out.join("\n") };
    }
    if (/排序/.test(t)) {
      const lines = src.split(/\n/).filter(x => x.trim());
      const nums = lines.every(l => !isNaN(parseFloat(l)));
      lines.sort((a, b) => nums ? parseFloat(a) - parseFloat(b) : a.localeCompare(b, "zh-CN"));
      return { role: "ai", actions: true, content: "排好了：\n" + lines.join("\n") };
    }
    if (/去空行|空行/.test(t)) return { role: "ai", actions: true, content: "清好了：\n" + src.split(/\n/).filter(x => x.trim()).join("\n") };
    if (/提取.*(数字|金额)|所有数字/.test(t)) {
      const nums = src.match(/-?\d+(?:\.\d+)?/g) || [];
      return { role: "ai", content: `提取到：
共 ${nums.length} 个：\n${nums.join("、")}${nums.length ? `\n\n合计：${nums.reduce((a, b) => a + parseFloat(b), 0)}` : ""}` };
    }
    if (/提取.*(邮箱|邮件)/.test(t)) return { role: "ai", content: "邮箱在这里：\n" + ((src.match(/[\w.+-]+@[\w-]+\.[\w.]+/g) || ["未找到"]).join("\n")) };
    if (/提取.*(链接|网址|url)/i.test(t)) return { role: "ai", content: "链接在这里：\n" + ((src.match(/https?:\/\/[^\s，。]+/g) || ["未找到"]).join("\n")) };
    if (/转大写|变大写/.test(t)) return { role: "ai", actions: true, content: src.toUpperCase() };
    if (/转小写|变小写/.test(t)) return { role: "ai", actions: true, content: src.toLowerCase() };
    return null;
  },

  /* 确定性任务：算数 / 日期 / 文本工具 / 办公知识库
     —— 这类必须走规则，小模型在这上面最容易一本正经编错 */
  deterministic(t) {
    const ia = this.identityAnswer(t); if (ia) return ia;
    const c = this.calc(t); if (c) return { role: "ai", content: c };
    const d = this.dates(t); if (d) return { role: "ai", content: d };
    const onDoc = /[「“"]/.test(t) || /(这段|这个|上面|当前文档|选中|全文|我写的)/.test(t);
    if (onDoc) { const tt = this.textTool(t); if (tt) return tt; }
    const isGen = /写一?份|写一?个|帮我写|起草|生成|拟一?份|做一?份|翻译|扩写|缩写|改写成/.test(t);
    if (!isGen) for (const item of KB) if (item.k.test(t)) return { role: "ai", actions: true, content: item.a };
    return null;
  },

  handle(text) {
    const t = text.trim();
    const doc = this.docText();

    const det = this.deterministic(t);
    if (det) return det;

    if (/周报|周工作|本周工作/.test(t)) {
      const d = new Date().toLocaleDateString("zh-CN");
      const done = doc.length > 30
        ? doc.split(/\n/).filter(x => x.trim()).slice(0, 8).map(x => "- " + x.trim().replace(/^[-*#\d.]+\s*/, "")).join("\n")
        : "1. \n2. \n3. ";
      return { role: "ai", actions: true, content: `【周报】\n\n工作周报（${d}）\n\n一、本周完成\n${done}\n\n二、遇到的问题\n1. \n\n三、下周计划\n1. \n2. \n\n四、需要的支持\n\n—— ${doc.length > 30 ? "「本周完成」已从当前文档自动提炼，请核对。" : "当前文档为空，已给通用框架；把本周做的事写进文档后再让我生成，我会自动提炼。"}` };
    }
    if (/润色|改写|优化文字|通顺/.test(t)) {
      if (doc.length < 20) return { role: "ai", content: "当前文档内容太少（少于 20 字），先写点东西我再润色。" };
      const cleaned = doc.replace(/[ \t]+/g, " ")
        .replace(/([\u4e00-\u9fa5])[,;](?=[\u4e00-\u9fa5])/g, "$1，")
        .replace(/([\u4e00-\u9fa5])\.(?=\s|$)/g, "$1。")
        .replace(/([\u4e00-\u9fa5])\?(?=[\s\u4e00-\u9fa5]|$)/g, "$1？")
        .replace(/([\u4e00-\u9fa5])!(?=[\s\u4e00-\u9fa5]|$)/g, "$1！")
        .replace(/\n{3,}/g, "\n\n").trim();
      return { role: "ai", actions: true, content: `改好了：\n\n\n${cleaned}\n\n—— 已统一中文标点、清理多余空白（精简 ${Math.max(0, doc.length - cleaned.length)} 字符）。语义级改写需本地大模型。` };
    }
    if (/总结|要点|提炼|摘要/.test(t)) {
      if (doc.length < 30) return { role: "ai", content: "文档内容太少（少于 30 字），无法提炼要点。" };
      const paras = doc.split(/\n+/).map(x => x.trim()).filter(x => x.length > 4);
      const picks = paras.slice(0, 6).map((p, i) => `${i + 1}. ${p.slice(0, 46)}${p.length > 46 ? "…" : ""}`);
      return { role: "ai", actions: true, content: `要点如下：\n\n\n${picks.join("\n")}\n\n—— 取自文档各段主旨句（共 ${paras.length} 段），请人工确认。` };
    }
    if (/大纲|提纲|框架/.test(t)) {
      const topic = (t.match(/(?:关于|写|拟|做|一个)([^的，。]{2,20})(?:的)?(?:大纲|提纲|框架)/) || [])[1] || "项目";
      return { role: "ai", actions: true, content: `大纲（${topic}】\n\n一、背景与目标\n  1.1 现状与痛点\n  1.2 目标与衡量指标\n二、方案\n  2.1 整体思路\n  2.2 关键动作与分工\n  2.3 里程碑\n三、资源与预算\n四、风险与应对\n五、下一步\n\n—— 本地引擎给通用骨架；装本地大模型后可按具体主题展开成文。` };
    }

    const c2 = this.calc(t); if (c2) return { role: "ai", content: c2 };
    const d2 = this.dates(t); if (d2) return { role: "ai", content: d2 };

    for (const item of KB) if (item.k.test(t)) return { role: "ai", actions: true, content: item.a };

    return { role: "ai", content:
      "这个问题超出我的离线规则库，我不编答案。\n\n我现在能精确处理：\n· 算数：1280*0.85 等于多少\n· 日期推算：2026-11-01 到 2027-03-15 差几天\n· 文本处理：去重 / 排序 / 去空行 / 统计 / 提取数字邮箱链接\n· 文档动作：写周报、生成大纲、润色、提炼要点（读当前文档）\n· 办公常识：排版、Excel 函数、PPT 结构、邮件、会议纪要、OKR\n\n开放式问题请走本地大模型（设置页可一键启动，全程离线、不联网、不上传）。" };
  }
};

/* =========================================================
   设置
   ========================================================= */
const Settings = {
  async load() {
    try {
      const cfg = await bridge.call("get_config");
      document.getElementById("cfg-base").value = cfg.api_base || "";
      document.getElementById("cfg-key").value = cfg.api_key || "";
      document.getElementById("cfg-model").value = cfg.model || "";
      document.getElementById("cfg-state").textContent = cfg.api_key ? "当前：联网模式" : "当前：离线引擎";
    } catch (e) { }
  },
  async save() {
    try {
      await bridge.call("set_config", {
        api_base: document.getElementById("cfg-base").value.trim(),
        api_key: document.getElementById("cfg-key").value.trim(),
        model: document.getElementById("cfg-model").value.trim(),
      });
      toast("配置已保存");
      document.getElementById("cfg-state").textContent = document.getElementById("cfg-key").value.trim() ? "当前：云端模型" : "当前：本地 / 离线引擎";
      AI._cfg = null; AI._local = null;
      AI.refreshBadges();
    } catch (e) { toast(e.message); }
  },
  async test() {
    try {
      const cfg = await bridge.call("get_config");
      if (!cfg.api_key) return toast("请先填 API Key（或改用本地模型）");
      toast("正在测试…");
      const r = await bridge.call("ai_chat", [{ role: "user", content: "回复一个字：好" }], cfg.api_base, cfg.api_key, cfg.model);
      r.ok ? toast("连接成功，模型已响应 ✓") : toast("失败：" + r.error);
    } catch (e) { toast(e.message); }
  }
};

/* ---------- 本地模型管理 ---------- */
const LocalModel = {
  async refresh() {
    const st = await bridge.call("local_status").catch(() => null);
    const badge = document.getElementById("lm-badge");
    const state = document.getElementById("lm-state");
    if (!st) { badge.textContent = "未连接"; state.textContent = "客户端未连接（浏览器预览模式）。"; return; }
    if (st.installed) {
      badge.textContent = st.running ? "已就绪" : "已安装未启动";
      state.innerHTML = `模型：<b>${esc(st.model || "")}</b>（${fmtSize(st.model_size)}）· 端口 ${st.port} · ${st.running ? "推理服务运行中" : "点击下方按钮启动"}`;
    } else {
      badge.textContent = "未安装";
      state.innerHTML = `未找到本地模型。${st.exe ? "运行时已就位，只缺模型文件。" : "运行时与模型都缺。"}`;
    }
    document.getElementById("lm-llmdir").textContent = "llm\\";
    document.getElementById("lm-modeldir").textContent = "models\\";
  },
  async warmup() {
    const t0 = Date.now();
    toast("正在启动本地模型（首次加载 5–30 秒）…", 8000);
    const r = await bridge.call("local_warmup").catch(e => ({ ok: false, error: e.message }));
    const el = ((Date.now() - t0) / 1000).toFixed(1);
    if (r.ok) { toast(`本地模型已就绪 ✓ （${el}s，占内存约 2.3GB）`); AI._local = null; AI.refreshBadges(); }
    else toast("未启动：" + (r.error || "未知错误"), 5000);
    this.refresh();
  },
  async stop() {
    const r = await bridge.call("local_stop").catch(e => ({ ok: false, error: e.message }));
    AI._local = null; AI.refreshBadges();
    toast(r.freed ? "本地模型已停止，内存已释放" : "推理服务未在运行");
    this.refresh();
  },
  openDir() { bridge.call("open_model_dir").catch(e => toast(e.message)); }
};

/* =========================================================
   App 全局
   ========================================================= */
const App = {
  fullscreen() { document.documentElement.requestFullscreen?.().catch(() => {}); }
};

window.__openFromArg = function (p) {
  const ex = ext(p);
  if (IMAGE_EXTS.includes(ex)) { go("images"); Images.openPath(p); }
  else if (ex === ".csv") Sheets.openPath(p);
  else if (TEXT_EXTS.includes(ex)) Writer.openPath(p);
  else bridge.call("open_external", p);
};

document.addEventListener("keydown", e => {
  if (e.key === "Escape") {
    if (!document.getElementById("present").classList.contains("hidden")) Slides.exit();
    else if (!document.getElementById("new-modal").classList.contains("hidden")) NewDlg.close();
    else if (document.getElementById("dyn-modal")) document.getElementById("dyn-modal").remove();
  }
  if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "s") {
    e.preventDefault();
    const v = document.querySelector(".view.active")?.id;
    if (v === "view-writer") Writer.save();
    else if (v === "view-sheets") Sheets.save();
    else if (v === "view-slides") Slides.save();
  }
  if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "p" && document.querySelector("#view-writer.active")) {
    e.preventDefault();
    Writer.print();
  }
  if (document.querySelector("#view-files.active")) {
    if (e.key === "F2" && FM.sel) FM.renameSelected();
    if (e.key === "Delete" && FM.sel) FM.deleteSelected();
    if (e.key === "Enter" && FM.sel) FM.openSelected();
  }
  if (document.querySelector("#view-sheets.active") && !e.target.isContentEditable && e.target.tagName !== "INPUT") {
    const p = Sheets.parseRef(Sheets.sel);
    if (e.key === "ArrowDown") { e.preventDefault(); Sheets.move(1, 0); }
    if (e.key === "ArrowUp") { e.preventDefault(); Sheets.move(-1, 0); }
    if (e.key === "ArrowLeft") { e.preventDefault(); Sheets.move(0, -1); }
    if (e.key === "ArrowRight") { e.preventDefault(); Sheets.move(0, 1); }
    if (e.key === "Enter") { e.preventDefault(); const td = document.querySelector(`td[data-k="${Sheets.sel}"]`); if (td) Sheets.edit(td); }
    if (e.key === "Delete") {
      e.preventDefault();
      const [a, b] = Sheets.rangeSel();
      Sheets.eachCell(a, b, k => delete Sheets.data[k]);
      Sheets.refreshCells();
    }
  }
});

window.addEventListener("DOMContentLoaded", () => {
  document.querySelectorAll(".rail-btn").forEach(b => b.onclick = () => go(b.dataset.view));
  const h = new Date().getHours();
  document.getElementById("greet").textContent =
    (h < 6 ? "夜深了" : h < 12 ? "早上好" : h < 14 ? "中午好" : h < 18 ? "下午好" : "晚上好") + "，从一份文档开始";
  Home.renderTemplates();
  Writer.init(); Sheets.init(); Slides.init(); Images.init(); AI.init();
  // 首屏只做最轻的三件事：模板、最近文件、AI 徽标；其余模块进入时再加载
  Home.loadRecent();
  setTimeout(() => { AI.refreshBadges(); Settings.load(); }, 600);
  const hash = (location.hash || "").replace("#", "");
  if (["home","files","writer","sheets","slides","images","ai","settings"].includes(hash)) setTimeout(() => go(hash), 50);
});

/* =========================================================
   全局兜底：任何脚本异常都要"看得见"，而不是白屏
   ========================================================= */
(function () {
  let shown = 0;
  function fatal(msg) {
    if (shown++ > 3) return;
    let box = document.getElementById("fatal-bar");
    if (!box) {
      box = document.createElement("div");
      box.id = "fatal-bar";
      box.style.cssText = [
        "position:fixed", "left:50%", "bottom:18px", "transform:translateX(-50%)", "z-index:99999",
        "max-width:78vw", "background:#fff", "border:1px solid rgba(230,57,46,.45)",
        "box-shadow:0 14px 44px rgba(20,20,30,.18)", "border-radius:14px", "padding:12px 16px",
        "font:12px/1.65 system-ui,'Segoe UI','Microsoft YaHei'", "color:#a3231a",
        "white-space:pre-wrap", "word-break:break-word", "user-select:text"
      ].join(";");
      document.body.appendChild(box);
    }
    box.textContent = "⚠ 界面出错（可截图反馈）\n" + msg;
  }
  window.addEventListener("error", e => fatal(
    (e.message || "脚本错误") + "\n" + (e.filename || "").split("/").pop() + ":" + (e.lineno || "?")
  ));
  window.addEventListener("unhandledrejection", e => {
    const r = e.reason;
    fatal(String((r && r.message) || r || "未知异步错误"));
  });
  // 首屏 4 秒后若当前视图仍为空，提示而不是干等
  setTimeout(() => {
    const v = document.querySelector(".view.active");
    if (!v || v.innerText.trim().length < 8) fatal("当前界面没有渲染出内容（可能资源未加载完整）");
  }, 4000);
})();
